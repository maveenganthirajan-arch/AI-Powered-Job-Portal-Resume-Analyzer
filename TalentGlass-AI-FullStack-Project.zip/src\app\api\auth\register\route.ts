import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { createSessionCookie } from "@/lib/auth";
import { registerSchema } from "@/lib/validations";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const validated = registerSchema.parse(body);

    const existing = await db.user.findUnique({
      where: { email: validated.email },
    });

    if (existing) {
      return NextResponse.json({ error: "Email already registered" }, { status: 409 });
    }

    const newUser = await db.user.create({
      data: {
        email: validated.email,
        name: validated.name,
        role: validated.role,
        avatar: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=250&q=80`,
        candidateProfile:
          validated.role === "CANDIDATE"
            ? {
                create: {
                  headline: "Software Engineer",
                  skills: JSON.stringify(["JavaScript", "TypeScript", "React"]),
                },
              }
            : undefined,
        company:
          validated.role === "RECRUITER"
            ? {
                create: {
                  name: validated.companyName || `${validated.name}'s Company`,
                  description: "Innovating modern digital work.",
                },
              }
            : undefined,
      },
    });

    const sessionUser = {
      id: newUser.id,
      email: newUser.email,
      name: newUser.name,
      role: newUser.role as any,
      avatar: newUser.avatar,
    };

    const cookieData = createSessionCookie(sessionUser);
    const response = NextResponse.json({ success: true, user: sessionUser });
    response.cookies.set(cookieData.name, cookieData.value, cookieData.options);

    return response;
  } catch (err: any) {
    return NextResponse.json({ error: err.message || "Registration failed" }, { status: 400 });
  }
}
