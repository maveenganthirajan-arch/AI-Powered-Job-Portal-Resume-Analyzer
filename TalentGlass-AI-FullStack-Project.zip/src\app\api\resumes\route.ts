import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ resumes: [] });
    }

    const resumes = await db.resume.findMany({
      where: { userId: user.id },
      include: {
        analyses: {
          orderBy: { createdAt: "desc" },
          take: 1,
        },
      },
      orderBy: { uploadedAt: "desc" },
    });

    const parsed = resumes.map((r) => ({
      ...r,
      parsedSkills: JSON.parse(r.parsedSkills || "[]"),
      analyses: r.analyses.map((a) => ({
        ...a,
        strengths: JSON.parse(a.strengths || "[]"),
        missingSkills: JSON.parse(a.missingSkills || "[]"),
        suggestions: JSON.parse(a.suggestions || "[]"),
      })),
    }));

    return NextResponse.json({ resumes: parsed });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
