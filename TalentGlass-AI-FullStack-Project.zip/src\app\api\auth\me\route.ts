import { NextResponse } from "next/server";
import { getCurrentUser, createSessionCookie } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ user: null });
  }

  // Get additional stats for current user
  let stats = {};
  if (user.role === "CANDIDATE") {
    const [appCount, interviewCount, savedCount] = await Promise.all([
      db.application.count({ where: { candidateId: user.id } }),
      db.application.count({ where: { candidateId: user.id, status: "INTERVIEW" } }),
      db.savedJob.count({ where: { userId: user.id } }),
    ]);
    stats = { appliedJobs: appCount, interviews: interviewCount, offers: 0, savedJobs: savedCount };
  } else if (user.role === "RECRUITER") {
    const company = await db.company.findUnique({ where: { ownerId: user.id } });
    if (company) {
      const [jobCount, appCount, shortlistedCount, interviewCount] = await Promise.all([
        db.job.count({ where: { companyId: company.id } }),
        db.application.count({ where: { job: { companyId: company.id } } }),
        db.application.count({ where: { job: { companyId: company.id }, status: "SHORTLISTED" } }),
        db.application.count({ where: { job: { companyId: company.id }, status: "INTERVIEW" } }),
      ]);
      stats = { totalJobs: jobCount, totalApplicants: appCount, shortlisted: shortlistedCount, interviews: interviewCount };
    }
  }

  return NextResponse.json({ user, stats });
}

// Switch demo user (Candidate John Doe <-> Recruiter Sarah Wilson)
export async function POST(req: Request) {
  try {
    const { role } = await req.json();
    let targetUser;

    if (role === "RECRUITER") {
      targetUser = await db.user.findFirst({ where: { role: "RECRUITER" } });
    } else {
      targetUser = await db.user.findFirst({ where: { role: "CANDIDATE" } });
    }

    if (!targetUser) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    const sessionUser = {
      id: targetUser.id,
      email: targetUser.email,
      name: targetUser.name,
      role: targetUser.role as any,
      avatar: targetUser.avatar,
    };

    const cookieData = createSessionCookie(sessionUser);
    const response = NextResponse.json({ success: true, user: sessionUser });
    response.cookies.set(cookieData.name, cookieData.value, cookieData.options);

    return response;
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 400 });
  }
}
