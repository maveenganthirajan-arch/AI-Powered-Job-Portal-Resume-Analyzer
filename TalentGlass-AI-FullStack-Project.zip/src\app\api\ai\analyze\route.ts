import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { analyzeResumeWithAI } from "@/services/ai-analyzer";
import { resumeAnalyzeSchema } from "@/lib/validations";

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    const body = await req.json();
    const validated = resumeAnalyzeSchema.parse(body);

    let resumeText = validated.rawResumeText || "";
    let resumeRecordId = validated.resumeId;

    if (validated.resumeId) {
      const resume = await db.resume.findUnique({
        where: { id: validated.resumeId },
      });
      if (resume?.extractedText) {
        resumeText = resume.extractedText;
      }
    }

    if (!resumeText) {
      // Check if user has an existing resume
      if (user) {
        const latestResume = await db.resume.findFirst({
          where: { userId: user.id },
          orderBy: { uploadedAt: "desc" },
        });
        if (latestResume?.extractedText) {
          resumeText = latestResume.extractedText;
          resumeRecordId = latestResume.id;
        }
      }
    }

    if (!resumeText) {
      return NextResponse.json(
        { error: "Please upload a resume or provide resume text to analyze." },
        { status: 400 }
      );
    }

    // Determine target job context
    let jobContext = {
      title: "Senior Full Stack Engineer",
      description: validated.customJobDescription || "Modern web development with React, TypeScript, and APIs.",
      requiredSkills: ["React", "TypeScript", "Next.js", "Node.js", "Tailwind CSS"],
      requirements: [
        "3+ years experience with React and TypeScript",
        "Experience building scalable full stack systems",
      ],
    };

    if (validated.jobId) {
      const dbJob = await db.job.findUnique({
        where: { id: validated.jobId },
      });
      if (dbJob) {
        jobContext = {
          title: dbJob.title,
          description: dbJob.description,
          requiredSkills: JSON.parse(dbJob.requiredSkills || "[]"),
          requirements: JSON.parse(dbJob.requirements || "[]"),
        };
      }
    }

    // Run AI Analysis
    const analysis = await analyzeResumeWithAI(resumeText, jobContext);

    // Save report to database if resume record exists
    let savedAnalysisId = null;
    if (resumeRecordId) {
      const saved = await db.resumeAnalysis.create({
        data: {
          resumeId: resumeRecordId,
          jobId: validated.jobId || null,
          overallScore: analysis.overallScore,
          skillsMatchScore: analysis.skillsMatchScore,
          experienceScore: analysis.experienceScore,
          projectsScore: analysis.projectsScore,
          educationScore: analysis.educationScore,
          strengths: JSON.stringify(analysis.strengths),
          missingSkills: JSON.stringify(analysis.missingSkills),
          suggestions: JSON.stringify(analysis.suggestions),
          jobMatchExplanation: analysis.jobMatchExplanation,
        },
      });
      savedAnalysisId = saved.id;
    }

    return NextResponse.json({
      success: true,
      analysisId: savedAnalysisId,
      result: analysis,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || "Analysis failed" }, { status: 400 });
  }
}
