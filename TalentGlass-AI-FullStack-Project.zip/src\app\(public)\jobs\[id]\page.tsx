"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { JobData } from "@/types";
import { GlassCard } from "@/components/glass-card";
import { ApplyModal } from "@/components/apply-modal";
import {
  ArrowLeft,
  Briefcase,
  MapPin,
  DollarSign,
  Clock,
  Sparkles,
  CheckCircle2,
  Bookmark,
  Building2,
  Share2,
  ExternalLink,
  ShieldCheck,
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function JobDetailsPage() {
  const params = useParams();
  const [job, setJob] = useState<JobData | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"overview" | "requirements" | "benefits" | "company">("overview");
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  useEffect(() => {
    if (params.id) {
      fetchJobDetails(params.id as string);
    }
  }, [params.id]);

  const fetchJobDetails = async (id: string) => {
    try {
      const res = await fetch(`/api/jobs/${id}`);
      if (res.ok) {
        const data = await res.json();
        setJob(data.job);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveToggle = async () => {
    if (!job) return;
    try {
      const res = await fetch("/api/saved-jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jobId: job.id }),
      });
      if (res.ok) {
        const data = await res.json();
        setIsSaved(data.saved);
      }
    } catch (e) {
      console.error(e);
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <div className="inline-block w-8 h-8 border-4 border-violet-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-xs text-slate-400 mt-3">Loading job details...</p>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-xl font-bold text-white">Job posting not found</h2>
        <Link href="/jobs" className="text-xs text-aqua underline">
          Return to job search
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Back link */}
      <div>
        <Link
          href="/jobs"
          className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          Back to jobs
        </Link>
      </div>

      {/* Main Header Glass Card (Matching Panel 3) */}
      <GlassCard className="p-6 sm:p-8 relative overflow-hidden border-white/15">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-start gap-5">
            <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center overflow-hidden shrink-0 shadow-lg">
              {job.company?.logo ? (
                <img
                  src={job.company.logo}
                  alt={job.company.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <Building2 className="w-8 h-8 text-violet-400" />
              )}
            </div>

            <div className="space-y-1.5">
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                {job.title}
              </h1>
              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300">
                <span className="font-semibold text-white flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-aqua" />
                  {job.company?.name || "TechCorp"}
                </span>
                <span>•</span>
                <span className="flex items-center gap-1 text-slate-400">
                  <MapPin className="w-3.5 h-3.5 text-aqua" />
                  {job.location}
                </span>
                <span>•</span>
                <span className="text-slate-400">{job.type}</span>
                <span>•</span>
                <span className="text-emerald-400 font-semibold">{job.salaryRange}</span>
              </div>
            </div>
          </div>

          {/* Action buttons (Panel 3: Apply Now, Save) */}
          <div className="flex items-center gap-3 w-full md:w-auto">
            <button
              onClick={() => setIsApplyModalOpen(true)}
              className="flex-1 md:flex-none px-6 py-3 rounded-xl bg-gradient-to-r from-violet-600 to-aqua text-white text-xs font-bold shadow-lg shadow-violet-500/25 hover:opacity-95 transition-all flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              Apply Now
            </button>
            <button
              onClick={handleSaveToggle}
              className={cn(
                "p-3 rounded-xl border transition-all flex items-center justify-center gap-1.5 text-xs font-medium",
                isSaved
                  ? "bg-violet-600/20 border-violet-500/50 text-violet-400"
                  : "bg-white/5 border-white/10 text-slate-400 hover:text-white"
              )}
            >
              <Bookmark className={cn("w-4 h-4", isSaved && "fill-violet-400")} />
              <span>{isSaved ? "Saved" : "Save"}</span>
            </button>
          </div>
        </div>

        {/* Tab buttons (Overview, Requirements, Benefits, Company) */}
        <div className="flex items-center gap-2 mt-8 pt-6 border-t border-white/10 overflow-x-auto">
          {[
            { id: "overview", label: "Overview" },
            { id: "requirements", label: "Requirements" },
            { id: "benefits", label: "Benefits" },
            { id: "company", label: "Company" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "px-4 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap",
                activeTab === tab.id
                  ? "bg-white/15 text-white border border-white/20 shadow-sm"
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </GlassCard>

      {/* Two Column Content: Left Tab Content, Right Job Highlights */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left main content */}
        <div className="lg:col-span-8 space-y-6">
          <GlassCard className="p-6 sm:p-8 space-y-6">
            {activeTab === "overview" && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-base font-bold text-white mb-3">About the job</h3>
                  <p className="text-sm text-slate-300 leading-relaxed whitespace-pre-line">
                    {job.description}
                  </p>
                </div>

                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                    Core Technical Requirements
                  </h4>
                  <ul className="space-y-2.5">
                    {job.requirements.map((req, i) => (
                      <li key={i} className="flex items-start gap-2.5 text-xs text-slate-300">
                        <CheckCircle2 className="w-4 h-4 text-aqua shrink-0 mt-0.5" />
                        <span>{req}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {activeTab === "requirements" && (
              <div className="space-y-4">
                <h3 className="text-base font-bold text-white">Full Role Requirements</h3>
                <ul className="space-y-3">
                  {job.requirements.map((req, i) => (
                    <li key={i} className="flex items-start gap-3 text-xs text-slate-300 p-3 rounded-xl bg-white/5 border border-white/5">
                      <span className="w-5 h-5 rounded-full bg-violet-600/30 text-aqua flex items-center justify-center font-bold text-[10px] shrink-0">
                        {i + 1}
                      </span>
                      <span>{req}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {activeTab === "benefits" && (
              <div className="space-y-4">
                <h3 className="text-base font-bold text-white">Compensation & Benefits</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {job.benefits.map((benefit, i) => (
                    <div key={i} className="p-4 rounded-xl bg-white/5 border border-white/10 space-y-1">
                      <div className="flex items-center gap-2 text-aqua text-xs font-semibold">
                        <Sparkles className="w-3.5 h-3.5" />
                        Perk {i + 1}
                      </div>
                      <p className="text-xs text-slate-300">{benefit}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === "company" && (
              <div className="space-y-4">
                <h3 className="text-base font-bold text-white">About {job.company?.name}</h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {job.company?.description || "An innovative technology enterprise shaping modern software solutions."}
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-3">
                  <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                    <span className="text-[10px] text-slate-400 uppercase">Location</span>
                    <p className="text-xs font-semibold text-white mt-0.5">{job.company?.location || job.location}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                    <span className="text-[10px] text-slate-400 uppercase">Team Size</span>
                    <p className="text-xs font-semibold text-white mt-0.5">{job.company?.teamSize || "500+ employees"}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 border border-white/5">
                    <span className="text-[10px] text-slate-400 uppercase">Website</span>
                    <p className="text-xs font-semibold text-aqua mt-0.5 truncate">{job.company?.website || "https://company.com"}</p>
                  </div>
                </div>
              </div>
            )}
          </GlassCard>
        </div>

        {/* Right Sidebar: Job Highlights (Panel 3) */}
        <div className="lg:col-span-4 space-y-6">
          <GlassCard className="p-6 space-y-6 border-white/15">
            <h3 className="text-sm font-bold uppercase tracking-wider text-white pb-3 border-b border-white/10">
              Job Highlights
            </h3>

            <div className="space-y-4 text-xs">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-aqua">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-slate-400 text-[11px]">Employment Type</span>
                  <p className="font-semibold text-white">{job.type}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-aqua">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-slate-400 text-[11px]">Location</span>
                  <p className="font-semibold text-white">{job.location}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-emerald-400">
                  <DollarSign className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-slate-400 text-[11px]">Salary Range</span>
                  <p className="font-semibold text-emerald-400">{job.salaryRange}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-violet-400">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-slate-400 text-[11px]">Experience</span>
                  <p className="font-semibold text-white">3+ years experience</p>
                </div>
              </div>
            </div>

            {/* Skills Pills matching Panel 3 */}
            <div className="pt-4 border-t border-white/10">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block mb-2.5">
                Required Tech Stack
              </span>
              <div className="flex flex-wrap gap-1.5">
                {job.requiredSkills.map((skill) => (
                  <span
                    key={skill}
                    className="px-2.5 py-1 rounded-lg bg-violet-600/20 border border-violet-500/30 text-slate-200 text-xs font-medium"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            {/* Direct Apply CTA */}
            <button
              onClick={() => setIsApplyModalOpen(true)}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-violet-600 to-aqua text-white text-xs font-bold shadow-lg shadow-violet-500/25 hover:opacity-95 transition-all"
            >
              Apply for this Position
            </button>
          </GlassCard>
        </div>
      </div>

      {/* Apply Modal */}
      <ApplyModal
        job={job}
        isOpen={isApplyModalOpen}
        onClose={() => setIsApplyModalOpen(false)}
      />
    </div>
  );
}
