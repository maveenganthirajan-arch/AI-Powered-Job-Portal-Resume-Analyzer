import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { getRecruiterApplicants } from "@/services/applications";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const applicants = await getRecruiterApplicants(user.id);
    return NextResponse.json({ applicants });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
