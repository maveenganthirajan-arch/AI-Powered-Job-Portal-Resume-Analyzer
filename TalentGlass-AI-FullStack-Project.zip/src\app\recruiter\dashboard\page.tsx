"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { GlassCard } from "@/components/glass-card";
import { getStatusColor, formatDate } from "@/lib/utils";
import {
  Briefcase,
  Users,
  UserCheck,
  Calendar,
  Sparkles,
  ArrowRight,
  TrendingUp,
  MoreVertical,
  CheckCircle2,
  XCircle,
  FileText,
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function RecruiterDashboardPage() {
  const [applicants, setApplicants] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  useEffect(() => {
    fetchApplicants();
  }, []);

  const fetchApplicants = async () => {
    try {
      const res = await fetch("/api/applications/me"); // or recruiter applicants endpoint
      // Fetch recruiter applicant data
      const recRes = await fetch("/api/recruiter/applicants");
      if (recRes.ok) {
        const data = await recRes.json();
        setApplicants(data.applicants || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickStatusChange = async (appId: string, newStatus: string) => {
    setUpdatingId(appId);
    try {
      const res = await fetch(`/api/applications/${appId}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus }),
      });
      if (res.ok) {
        setApplicants((prev) =>
          prev.map((a) => (a.id === appId ? { ...a, status: newStatus } : a))
        );
      }
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Hiring Overview
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            Monitor applicant velocity, review candidate matches, and advance pipeline stages.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/recruiter/jobs"
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-aqua text-white text-xs font-bold shadow-lg shadow-violet-500/20 hover:opacity-95 transition-all flex items-center gap-1.5"
          >
            <Briefcase className="w-4 h-4" />
            + Post New Job
          </Link>
        </div>
      </div>

      {/* 4 Stat Overview Cards matching Panel 6 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Jobs */}
        <GlassCard className="p-5 relative overflow-hidden border-white/10">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Total Jobs</span>
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
              <Briefcase className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white">5</span>
            <span className="text-[11px] font-medium text-emerald-400">+1 this week</span>
          </div>
        </GlassCard>

        {/* Total Applicants */}
        <GlassCard className="p-5 relative overflow-hidden border-white/10">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Total Applicants</span>
            <div className="w-8 h-8 rounded-lg bg-violet-500/10 border border-violet-500/20 flex items-center justify-center text-violet-400">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white">128</span>
            <span className="text-[11px] font-medium text-aqua">+24 this week</span>
          </div>
        </GlassCard>

        {/* Shortlisted */}
        <GlassCard className="p-5 relative overflow-hidden border-white/10">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Shortlisted</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <UserCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white">18</span>
            <span className="text-[11px] font-medium text-emerald-400">+5 this week</span>
          </div>
        </GlassCard>

        {/* Interviews */}
        <GlassCard className="p-5 relative overflow-hidden border-white/10">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Interviews</span>
            <div className="w-8 h-8 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white">7</span>
            <span className="text-[11px] font-medium text-purple-300">+2 this week</span>
          </div>
        </GlassCard>
      </div>

      {/* Recent Applicants Section (Panel 6) */}
      <GlassCard className="p-0 overflow-hidden border-white/15">
        <div className="p-5 flex items-center justify-between border-b border-white/10">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-aqua" />
              Recent Applicants
            </h3>
            <p className="text-xs text-slate-400">Candidates awaiting status advancement</p>
          </div>
          <Link
            href="/recruiter/applicants"
            className="text-xs font-semibold text-aqua hover:underline flex items-center gap-1"
          >
            Manage Pipeline <ArrowRight className="w-3 h-3" />
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-white/10 bg-white/[0.02] text-slate-400">
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px]">
                  Name
                </th>
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px]">
                  Position
                </th>
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px]">
                  Status
                </th>
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px]">
                  Applied On
                </th>
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px] text-right">
                  Quick Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {[
                { id: "app-1", name: "Alex Carter", position: "Frontend Developer", status: "SHORTLISTED", date: "Apr 15, 2026", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80" },
                { id: "app-2", name: "Priya Sharma", position: "Full Stack Developer", status: "INTERVIEW", date: "Apr 14, 2026", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80" },
                { id: "app-3", name: "Rahul Mehta", position: "Backend Developer", status: "APPLIED", date: "Apr 12, 2026", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80" },
                { id: "app-4", name: "Emily Davis", position: "UI/UX Designer", status: "IN_REVIEW", date: "Apr 10, 2026", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80" },
                { id: "app-5", name: "James Wilson", position: "Data Analyst", status: "REJECTED", date: "Apr 8, 2026", avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=150&q=80" },
              ].map((cand) => {
                const colors = getStatusColor(cand.status);
                return (
                  <tr key={cand.id} className="hover:bg-white/[0.03] transition-colors">
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                        <img
                          src={cand.avatar}
                          alt={cand.name}
                          className="w-8 h-8 rounded-full object-cover border border-white/20"
                        />
                        <span className="font-semibold text-white">{cand.name}</span>
                      </div>
                    </td>
                    <td className="py-4 px-6 text-slate-300 font-medium">{cand.position}</td>
                    <td className="py-4 px-6">
                      <span
                        className={cn(
                          "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold border",
                          colors.bg,
                          colors.text,
                          colors.border
                        )}
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-current" />
                        {cand.status.replace("_", " ")}
                      </span>
                    </td>
                    <td className="py-4 px-6 text-slate-400 font-mono text-[11px]">{cand.date}</td>
                    <td className="py-4 px-6 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Link
                          href="/recruiter/applicants"
                          className="px-3 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 text-[11px] font-semibold transition-colors"
                        >
                          Review
                        </Link>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
}
