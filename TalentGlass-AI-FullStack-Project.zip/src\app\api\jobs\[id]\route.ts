import { NextResponse } from "next/server";
import { getJobById } from "@/services/jobs";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";

export async function GET(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const job = await getJobById(params.id);
    if (!job) {
      return NextResponse.json({ error: "Job not found" }, { status: 404 });
    }
    return NextResponse.json({ job });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function PATCH(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== "RECRUITER") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
    }

    const company = await db.company.findUnique({
      where: { ownerId: user.id },
    });

    const job = await db.job.findUnique({ where: { id: params.id } });
    if (!job || job.companyId !== company?.id) {
      return NextResponse.json({ error: "Not authorized to update this job" }, { status: 403 });
    }

    const body = await req.json();
    const updated = await db.job.update({
      where: { id: params.id },
      data: {
        ...(body.title && { title: body.title }),
        ...(body.department && { department: body.department }),
        ...(body.location && { location: body.location }),
        ...(body.salaryRange && { salaryRange: body.salaryRange }),
        ...(body.status && { status: body.status }),
        ...(body.description && { description: body.description }),
        ...(body.requirements && { requirements: JSON.stringify(body.requirements) }),
        ...(body.requiredSkills && { requiredSkills: JSON.stringify(body.requiredSkills) }),
      },
    });

    return NextResponse.json({ success: true, job: updated });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}
