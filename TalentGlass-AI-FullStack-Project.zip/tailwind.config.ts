import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "#0B1020",
        foreground: "#F8FAFC",
        midnight: {
          950: "#060913",
          900: "#0B1020",
          850: "#0F162B",
          800: "#131C38",
          700: "#1D2A54",
          600: "#2B3C73",
        },
        violet: {
          electric: "#7C5CFC",
          glow: "#9373FF",
          subtle: "#5A3EE0",
        },
        aqua: {
          DEFAULT: "#35D6C5",
          bright: "#4FF6E4",
          glow: "#1ABDAA",
          muted: "rgba(53, 214, 197, 0.15)",
        },
        glass: {
          bg: "rgba(255, 255, 255, 0.05)",
          card: "rgba(255, 255, 255, 0.07)",
          hover: "rgba(255, 255, 255, 0.11)",
          active: "rgba(255, 255, 255, 0.15)",
          border: "rgba(255, 255, 255, 0.12)",
          "border-hover": "rgba(255, 255, 255, 0.25)",
        },
      },
      boxShadow: {
        glass: "0 12px 40px rgba(0, 0, 0, 0.28)",
        "glass-sm": "0 4px 20px rgba(0, 0, 0, 0.18)",
        "glow-violet": "0 0 30px rgba(124, 92, 252, 0.35)",
        "glow-aqua": "0 0 30px rgba(53, 214, 197, 0.35)",
      },
      backgroundImage: {
        "gradient-radial": "radial-gradient(var(--tw-gradient-stops))",
        "radial-violet": "radial-gradient(circle at 50% 0%, rgba(124, 92, 252, 0.22) 0%, transparent 60%)",
        "radial-aqua": "radial-gradient(circle at 100% 100%, rgba(53, 214, 197, 0.15) 0%, transparent 60%)",
      },
      borderRadius: {
        glass: "20px",
        "glass-sm": "12px",
        "glass-lg": "24px",
      },
      backdropBlur: {
        xs: "2px",
        glass: "16px",
      },
    },
  },
  plugins: [],
};
export default config;
