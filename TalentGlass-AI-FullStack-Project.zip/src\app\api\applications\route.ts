import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { applicationCreateSchema } from "@/lib/validations";
import { computeDeterministicMatch } from "@/services/ai-analyzer";

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Please log in to apply" }, { status: 401 });
    }

    const body = await req.json();
    const validated = applicationCreateSchema.parse(body);

    // Prevent duplicate applications
    const existing = await db.application.findUnique({
      where: {
        candidateId_jobId: {
          candidateId: user.id,
          jobId: validated.jobId,
        },
      },
    });

    if (existing) {
      return NextResponse.json({ error: "You have already applied for this job." }, { status: 409 });
    }

    // Retrieve resume and job to compute match score snapshot
    const [resume, job] = await Promise.all([
      db.resume.findUnique({ where: { id: validated.resumeId } }),
      db.job.findUnique({ where: { id: validated.jobId }, include: { company: true } }),
    ]);

    if (!job) {
      return NextResponse.json({ error: "Job posting not found" }, { status: 404 });
    }

    let calculatedScore = 75;
    if (resume?.extractedText) {
      const match = computeDeterministicMatch(resume.extractedText, {
        title: job.title,
        description: job.description,
        requiredSkills: JSON.parse(job.requiredSkills || "[]"),
        requirements: JSON.parse(job.requirements || "[]"),
      });
      calculatedScore = match.overallScore;
    }

    const application = await db.application.create({
      data: {
        candidateId: user.id,
        jobId: validated.jobId,
        resumeId: validated.resumeId,
        coverLetter: validated.coverLetter,
        matchScore: calculatedScore,
        status: "APPLIED",
      },
    });

    // Notify candidate
    await db.notification.create({
      data: {
        userId: user.id,
        title: "Application Submitted",
        message: `Your application for ${job.title} at ${job.company?.name || "the company"} has been received.`,
        type: "APPLICATION_STATUS",
        link: "/candidate/applications",
      },
    });

    // Notify recruiter
    if (job.company?.ownerId) {
      await db.notification.create({
        data: {
          userId: job.company.ownerId,
          title: "New Candidate Applied",
          message: `${user.name} applied for ${job.title} (Match: ${calculatedScore}%).`,
          type: "APPLICATION_STATUS",
          link: "/recruiter/applicants",
        },
      });
    }

    return NextResponse.json({ success: true, application }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}
