import { db } from "@/lib/db";
import { JobData } from "@/types";

export interface JobFilters {
  query?: string;
  location?: string;
  type?: string;
  experienceLevel?: string;
  page?: number;
  limit?: number;
}

export async function getJobs(filters: JobFilters = {}) {
  const { query, location, type, experienceLevel, page = 1, limit = 20 } = filters;
  const skip = (page - 1) * limit;

  const where: any = {
    status: "ACTIVE",
  };

  if (query) {
    where.OR = [
      { title: { contains: query } },
      { description: { contains: query } },
      { requiredSkills: { contains: query } },
    ];
  }

  if (location && location !== "All") {
    where.location = { contains: location };
  }

  if (type && type !== "All") {
    where.type = { contains: type };
  }

  if (experienceLevel && experienceLevel !== "All") {
    where.experienceLevel = experienceLevel;
  }

  const [jobs, total] = await Promise.all([
    db.job.findMany({
      where,
      include: {
        company: true,
        _count: {
          select: { applications: true },
        },
      },
      orderBy: [{ featured: "desc" }, { createdAt: "desc" }],
      skip,
      take: limit,
    }),
    db.job.count({ where }),
  ]);

  const parsedJobs: JobData[] = jobs.map((job) => ({
    ...job,
    requirements: JSON.parse(job.requirements || "[]"),
    benefits: JSON.parse(job.benefits || "[]"),
    requiredSkills: JSON.parse(job.requiredSkills || "[]"),
    status: job.status as any,
  }));

  return {
    jobs: parsedJobs,
    total,
    page,
    totalPages: Math.ceil(total / limit),
  };
}

export async function getJobById(id: string): Promise<JobData | null> {
  const job = await db.job.findUnique({
    where: { id },
    include: {
      company: true,
      _count: {
        select: { applications: true },
      },
    },
  });

  if (!job) return null;

  return {
    ...job,
    requirements: JSON.parse(job.requirements || "[]"),
    benefits: JSON.parse(job.benefits || "[]"),
    requiredSkills: JSON.parse(job.requiredSkills || "[]"),
    status: job.status as any,
  };
}
