import { NextResponse } from "next/server";
import { getJobs } from "@/services/jobs";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { jobCreateSchema } from "@/lib/validations";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const query = searchParams.get("query") || undefined;
    const location = searchParams.get("location") || undefined;
    const type = searchParams.get("type") || undefined;
    const experienceLevel = searchParams.get("experienceLevel") || undefined;
    const page = parseInt(searchParams.get("page") || "1", 10);
    const limit = parseInt(searchParams.get("limit") || "15", 10);

    const result = await getJobs({ query, location, type, experienceLevel, page, limit });
    return NextResponse.json(result);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== "RECRUITER") {
      return NextResponse.json({ error: "Only recruiters can post jobs" }, { status: 403 });
    }

    const company = await db.company.findUnique({
      where: { ownerId: user.id },
    });

    if (!company) {
      return NextResponse.json({ error: "Company profile required to publish jobs" }, { status: 400 });
    }

    const body = await req.json();
    const validated = jobCreateSchema.parse(body);

    const job = await db.job.create({
      data: {
        companyId: company.id,
        title: validated.title,
        department: validated.department,
        type: validated.type,
        experienceLevel: validated.experienceLevel,
        location: validated.location,
        salaryRange: validated.salaryRange,
        description: validated.description,
        requirements: JSON.stringify(validated.requirements),
        benefits: JSON.stringify(validated.benefits),
        requiredSkills: JSON.stringify(validated.requiredSkills),
        status: "ACTIVE",
        featured: true,
      },
    });

    return NextResponse.json({ success: true, job }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}
