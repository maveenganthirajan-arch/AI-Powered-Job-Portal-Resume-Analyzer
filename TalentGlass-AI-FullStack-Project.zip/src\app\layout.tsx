import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  fallback: ["system-ui", "-apple-system", "BlinkMacSystemFont", "Segoe UI", "Roboto", "sans-serif"],
});

export const metadata: Metadata = {
  title: "TalentGlass AI · AI-Powered Job Portal & Resume Analyzer (2026)",
  description:
    "Complete Full-Stack Project Blueprint with Glassmorphism UI. Search jobs, upload resumes, get structured AI feedback, and manage recruitment pipelines.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.className} min-h-screen bg-[#0B1020] text-slate-100 relative selection:bg-violet-500/30 selection:text-aqua`}>
        {/* Ambient background light glows matching 2026 Glassmorphism design system */}
        <div className="glow-orb-violet top-[-100px] left-[-150px]" />
        <div className="glow-orb-aqua top-[20%] right-[-180px]" />
        <div className="glow-orb-violet bottom-[15%] left-[10%]" />

        <div className="relative z-10 flex flex-col min-h-screen">
          <Navbar />
          <main className="flex-1">{children}</main>
          <Footer />
        </div>
      </body>
    </html>
  );
}
