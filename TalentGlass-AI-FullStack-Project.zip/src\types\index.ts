// TalentGlass AI - Core Type Definitions

export type Role = "CANDIDATE" | "RECRUITER" | "ADMIN";

export type ApplicationStatus =
  | "APPLIED"
  | "IN_REVIEW"
  | "SHORTLISTED"
  | "INTERVIEW"
  | "OFFERED"
  | "REJECTED";

export type JobStatus = "ACTIVE" | "CLOSED" | "DRAFT";

export interface UserSession {
  id: string;
  email: string;
  name: string;
  role: Role;
  avatar?: string | null;
}

export interface CandidateProfileData {
  id: string;
  userId: string;
  headline?: string | null;
  bio?: string | null;
  location?: string | null;
  experienceYears: number;
  phone?: string | null;
  website?: string | null;
  github?: string | null;
  linkedin?: string | null;
  skills: string[];
  education: Array<{
    degree: string;
    institution: string;
    year: string;
  }>;
  workHistory: Array<{
    role: string;
    company: string;
    period: string;
    description: string;
  }>;
}

export interface CompanyData {
  id: string;
  ownerId: string;
  name: string;
  logo?: string | null;
  description?: string | null;
  website?: string | null;
  location?: string | null;
  industry?: string | null;
  teamSize?: string | null;
}

export interface JobData {
  id: string;
  companyId: string;
  company?: CompanyData;
  title: string;
  department?: string | null;
  type: string;
  experienceLevel: string;
  location: string;
  salaryRange: string;
  description: string;
  requirements: string[];
  benefits: string[];
  requiredSkills: string[];
  status: JobStatus;
  featured: boolean;
  createdAt: string | Date;
  updatedAt?: string | Date;
  _count?: {
    applications?: number;
  };
}

export interface ResumeData {
  id: string;
  userId: string;
  fileName: string;
  fileUrl?: string | null;
  storageKey?: string | null;
  extractedText?: string | null;
  parsedSkills: string[];
  uploadedAt: string | Date;
}

export interface AIAnalysisResult {
  overallScore: number;
  skillsMatchScore: number;
  experienceScore: number;
  projectsScore: number;
  educationScore: number;
  strengths: string[];
  missingSkills: string[];
  suggestions: string[];
  jobMatchExplanation: string;
}

export interface ApplicationData {
  id: string;
  candidateId: string;
  candidate?: {
    id: string;
    name: string;
    email: string;
    avatar?: string | null;
  };
  jobId: string;
  job?: JobData;
  resumeId: string;
  resume?: ResumeData;
  status: ApplicationStatus;
  coverLetter?: string | null;
  matchScore?: number | null;
  appliedAt: string | Date;
  updatedAt?: string | Date;
}

export interface NotificationData {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: string;
  read: boolean;
  link?: string | null;
  createdAt: string | Date;
}
