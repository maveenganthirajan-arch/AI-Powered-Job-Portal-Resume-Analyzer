import React from "react";
import { InteractiveBlueprint } from "@/components/interactive-blueprint";
import { GlassCard } from "@/components/glass-card";
import { Layers, Sparkles, ExternalLink, ShieldCheck } from "lucide-react";

export default function BlueprintPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Blueprint Header */}
      <div className="relative p-8 md:p-12 rounded-3xl glass-card overflow-hidden border border-white/20">
        <div className="absolute top-0 right-0 w-80 h-80 bg-gradient-to-bl from-violet-600/30 to-transparent blur-3xl pointer-events-none" />

        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-600/20 border border-violet-500/30 text-xs font-semibold text-violet-300 mb-4">
          <Layers className="w-3.5 h-3.5" />
          TalentGlass AI · 2026 Production Blueprint
        </div>

        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          System Architecture & Technical Blueprint
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-2xl leading-relaxed">
          Comprehensive full-stack breakdown of TalentGlass AI: Glassmorphism UI, Next.js 14 App Router, Prisma ORM, transparent 40/25/20/15 AI matching logic, and deployment topology.
        </p>
      </div>

      {/* Interactive Blueprint Viewer */}
      <InteractiveBlueprint />
    </div>
  );
}
