import { z } from "zod";

export const registerSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  role: z.enum(["CANDIDATE", "RECRUITER"]).default("CANDIDATE"),
  companyName: z.string().optional(),
});

export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(1, "Password is required"),
});

export const jobCreateSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  department: z.string().optional(),
  type: z.string().default("Full-time"),
  experienceLevel: z.string().default("Mid-Level"),
  location: z.string().min(2, "Location is required"),
  salaryRange: z.string().min(2, "Salary range is required"),
  description: z.string().min(20, "Job description must be at least 20 characters"),
  requirements: z.array(z.string()).min(1, "At least one requirement is required"),
  benefits: z.array(z.string()).default([]),
  requiredSkills: z.array(z.string()).min(1, "At least one required skill is required"),
});

export const resumeAnalyzeSchema = z.object({
  resumeId: z.string().optional(),
  rawResumeText: z.string().optional(),
  jobId: z.string().optional(),
  customJobDescription: z.string().optional(),
});

export const applicationCreateSchema = z.object({
  jobId: z.string().min(1, "Job ID is required"),
  resumeId: z.string().min(1, "Resume is required"),
  coverLetter: z.string().optional(),
});

export const applicationStatusUpdateSchema = z.object({
  status: z.enum(["APPLIED", "IN_REVIEW", "SHORTLISTED", "INTERVIEW", "OFFERED", "REJECTED"]),
  notes: z.string().optional(),
});
