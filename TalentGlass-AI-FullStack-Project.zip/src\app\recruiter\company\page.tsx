import React from "react";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { GlassCard } from "@/components/glass-card";
import { Building2, Globe, MapPin, Users, Sparkles, CheckCircle2 } from "lucide-react";

export const revalidate = 0;

export default async function RecruiterCompanyPage() {
  const user = await getCurrentUser();
  const company = await db.company.findUnique({
    where: { ownerId: user?.id || "" },
  });

  return (
    <div className="space-y-8 max-w-4xl">
      <div className="space-y-1">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Company Profile & Brand
        </h1>
        <p className="text-xs sm:text-sm text-slate-400">
          Manage public organization details, employer branding, and candidate messaging.
        </p>
      </div>

      <GlassCard className="p-8 space-y-6 border-white/15">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
          <div className="w-20 h-20 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center overflow-hidden shrink-0 shadow-xl">
            {company?.logo ? (
              <img src={company.logo} alt="Company logo" className="w-full h-full object-cover" />
            ) : (
              <Building2 className="w-10 h-10 text-aqua" />
            )}
          </div>
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-white">{company?.name || "TechCorp Hiring"}</h2>
            <p className="text-xs text-aqua">{company?.industry || "Software & Cloud Services"}</p>
            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-1">
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-aqua" />
                {company?.location || "Mountain View, CA / Remote"}
              </span>
              <span className="flex items-center gap-1">
                <Users className="w-3.5 h-3.5 text-violet-400" />
                {company?.teamSize || "10,000+ employees"}
              </span>
              <span className="flex items-center gap-1">
                <Globe className="w-3.5 h-3.5 text-emerald-400" />
                {company?.website || "https://careers.google.com"}
              </span>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-white/10 space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            About the Organization
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            {company?.description || "A world-leading technology enterprise pioneering artificial intelligence, cloud architectures, and web-scale consumer platforms."}
          </p>
        </div>

        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-emerald-400 font-semibold">
            <CheckCircle2 className="w-4 h-4" />
            <span>Verified Employer Status</span>
          </div>
          <span className="text-slate-400">Owner: {user?.name || "Sarah Wilson"}</span>
        </div>
      </GlassCard>
    </div>
  );
}
