import React from "react";
import { Sidebar } from "@/components/sidebar";
import { getCurrentUser } from "@/lib/auth";

export default async function CandidateLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getCurrentUser();

  return (
    <div className="flex max-w-7xl mx-auto min-h-[calc(100vh-4rem)]">
      <Sidebar role="CANDIDATE" user={user || undefined} />
      <div className="flex-1 p-4 sm:p-6 lg:p-8 min-w-0">{children}</div>
    </div>
  );
}
