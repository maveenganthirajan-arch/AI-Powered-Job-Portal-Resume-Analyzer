import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { saveResumeFile } from "@/lib/storage";
import { extractTextFromFile, extractSkillsFromText } from "@/services/resume-parser";
import { db } from "@/lib/db";

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 MB

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const formData = await req.formData();
    const file = formData.get("file") as File | null;

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json({ error: "File size exceeds 5MB limit" }, { status: 400 });
    }

    const validExtensions = ["pdf", "docx", "doc", "txt"];
    const ext = file.name.split(".").pop()?.toLowerCase() || "";
    if (!validExtensions.includes(ext)) {
      return NextResponse.json(
        { error: "Invalid file format. Please upload PDF, DOCX, or TXT" },
        { status: 400 }
      );
    }

    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    // Save to private local storage
    const stored = await saveResumeFile(buffer, file.name, file.type);

    // Extract text and skills
    const extractedText = await extractTextFromFile(buffer, file.name, file.type);
    const parsedSkills = extractSkillsFromText(extractedText);

    // Persist to database
    const resume = await db.resume.create({
      data: {
        userId: user.id,
        fileName: file.name,
        fileUrl: stored.fileUrl,
        storageKey: stored.storageKey,
        extractedText,
        parsedSkills: JSON.stringify(parsedSkills),
      },
    });

    return NextResponse.json({
      success: true,
      resume: {
        ...resume,
        parsedSkills,
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || "Failed to upload resume" }, { status: 500 });
  }
}
