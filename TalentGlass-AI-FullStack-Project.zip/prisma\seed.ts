import "dotenv/config";
import { PrismaClient } from "@prisma/client";

if (!process.env.DATABASE_URL) {
  process.env.DATABASE_URL = "file:./dev.db";
}

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding TalentGlass AI database...");

  // Clean existing data
  await prisma.notification.deleteMany();
  await prisma.interview.deleteMany();
  await prisma.application.deleteMany();
  await prisma.resumeAnalysis.deleteMany();
  await prisma.resume.deleteMany();
  await prisma.savedJob.deleteMany();
  await prisma.job.deleteMany();
  await prisma.company.deleteMany();
  await prisma.candidateProfile.deleteMany();
  await prisma.user.deleteMany();

  // 1. Create Candidate User: John Doe
  const candidateUser = await prisma.user.create({
    data: {
      id: "candidate-john-doe",
      email: "john@example.com",
      name: "John Doe",
      role: "CANDIDATE",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80",
      candidateProfile: {
        create: {
          headline: "Senior Frontend Engineer & React Specialist",
          bio: "Passionate frontend engineer with 5+ years of experience crafting high-performance, accessible web applications with React, Next.js, and TypeScript.",
          location: "San Francisco, CA (Remote)",
          experienceYears: 5,
          phone: "+1 (555) 392-8192",
          website: "https://johndoe.dev",
          github: "https://github.com/johndoe",
          linkedin: "https://linkedin.com/in/johndoe",
          skills: JSON.stringify([
            "React",
            "Next.js",
            "TypeScript",
            "Tailwind CSS",
            "JavaScript",
            "HTML5/CSS3",
            "GraphQL",
            "REST APIs",
            "Git",
            "State Management (Zustand/Redux)",
            "Web Performance",
            "Responsive Design",
          ]),
          education: JSON.stringify([
            {
              degree: "B.S. in Computer Science",
              institution: "University of California, Berkeley",
              year: "2017 - 2021",
            },
          ]),
          workHistory: JSON.stringify([
            {
              role: "Senior Frontend Developer",
              company: "NovaTech Solutions",
              period: "2023 - Present",
              description: "Architected micro-frontends and led design system modernization reaching 1.2M monthly users.",
            },
            {
              role: "Frontend Engineer",
              company: "Vanguard Labs",
              period: "2021 - 2023",
              description: "Developed core dashboard features, optimized Web Vitals by 42%, and mentored junior engineers.",
            },
          ]),
        },
      },
    },
  });

  // 2. Create Candidate Resume
  const sampleResumeText = `
JOHN DOE
Senior Frontend Engineer | San Francisco, CA | john@example.com | https://johndoe.dev

SUMMARY
Passionate frontend engineer with 5+ years building accessible, responsive, and performant web apps in React, Next.js, and TypeScript. Experienced in micro-frontends, REST/GraphQL APIs, and design systems.

SKILLS
- Languages: TypeScript, JavaScript (ES6+), HTML5, CSS3, SQL basics
- Frameworks & Libraries: React, Next.js, Tailwind CSS, Redux Toolkit, Zustand, Shadcn UI
- Tools: Git, Webpack, Vite, Jest, Figma, Docker basics

EXPERIENCE
NovaTech Solutions - Senior Frontend Developer (2023 - Present)
- Engineered high-traffic responsive SaaS portal handling 1.2M monthly active sessions.
- Reduced Lighthouse performance TTFB and LCP by 42% through image optimization and server-side streaming.
- Built reusable component library adhering strictly to WCAG 2.1 AA accessibility standards.

Vanguard Labs - Frontend Engineer (2021 - 2023)
- Delivered 15+ complex client dashboard modules using Next.js App Router and TanStack Query.
- Collaborated with UI/UX design teams in Figma to translate wireframes into interactive prototypes.
- Implemented unit and integration tests achieving 82% coverage using Vitest and React Testing Library.

EDUCATION
B.S. in Computer Science - University of California, Berkeley (2017 - 2021)
  `.trim();

  const candidateResume = await prisma.resume.create({
    data: {
      id: "resume-john-primary",
      userId: candidateUser.id,
      fileName: "John_Doe_Senior_Frontend_Resume_2026.pdf",
      fileUrl: "/resumes/John_Doe_Senior_Frontend_Resume_2026.pdf",
      storageKey: "resumes/john_doe_2026_primary.pdf",
      extractedText: sampleResumeText,
      parsedSkills: JSON.stringify([
        "React",
        "Next.js",
        "TypeScript",
        "Tailwind CSS",
        "JavaScript",
        "Redux Toolkit",
        "Zustand",
        "REST APIs",
        "GraphQL",
        "Git",
        "Jest",
        "Vitest",
      ]),
    },
  });

  // 3. Create Recruiter User: Sarah Wilson
  const recruiterUser = await prisma.user.create({
    data: {
      id: "recruiter-sarah-wilson",
      email: "sarah@techcorp.com",
      name: "Sarah Wilson",
      role: "RECRUITER",
      avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=250&q=80",
      company: {
        create: {
          name: "Google & TechCorp Hiring",
          logo: "https://images.unsplash.com/photo-1572021335469-31706a17aaef?auto=format&fit=crop&w=120&q=80",
          description: "Global pioneer in web scale technologies, machine learning, and developer tools.",
          website: "https://google.com/careers",
          location: "Mountain View, CA / Remote",
          industry: "Software & Internet Services",
          teamSize: "10,000+ employees",
        },
      },
    },
    include: {
      company: true,
    },
  });

  const recruiterCompany = recruiterUser.company!;

  // 4. Create Jobs
  const jobGoogle = await prisma.job.create({
    data: {
      id: "job-google-frontend",
      companyId: recruiterCompany.id,
      title: "Senior Frontend Developer",
      department: "Google Cloud Console",
      type: "Remote · Full-time",
      experienceLevel: "Senior",
      location: "Remote / Mountain View, CA",
      salaryRange: "$100k - $150k",
      description:
        "We're looking for a Senior Frontend Developer to join our growing team. You'll work on exciting products, collaborate with talented engineers, and help build the next generation of web applications that empower millions of cloud developers worldwide.",
      requirements: JSON.stringify([
        "3+ years of professional production experience with React and TypeScript.",
        "Proven expertise in Next.js App Router, SSR, and modern client performance optimization.",
        "Deep knowledge of modern CSS, Tailwind CSS, and headless design component systems.",
        "Experience collaborating with Product Designers and backend microservices engineers.",
        "Strong understanding of web accessibility (a11y) and automated testing.",
      ]),
      benefits: JSON.stringify([
        "Comprehensive health, dental, and vision insurance with 100% premium coverage.",
        "Flexible 401(k) matching up to 6% and generous equity grants.",
        "Unlimited PTO and flexible remote working hours.",
        "$2,500 annual home office setup and continuous learning stipend.",
        "Annual international team retreat and top-tier hardware refreshes.",
      ]),
      requiredSkills: JSON.stringify(["React", "TypeScript", "Next.js", "CSS", "Tailwind CSS"]),
      status: "ACTIVE",
      featured: true,
    },
  });

  const jobMeta = await prisma.job.create({
    data: {
      id: "job-meta-fullstack",
      companyId: recruiterCompany.id,
      title: "Full Stack Developer",
      department: "Reality Labs & Social Graph",
      type: "Hybrid · Full-time",
      experienceLevel: "Mid-Level",
      location: "Menlo Park, CA / Hybrid",
      salaryRange: "$90k - $130k",
      description:
        "Join Meta's product team building real-time interactive collaboration experiences. You will architect robust Node.js backend services and create rich React frontend interfaces for millions of creators.",
      requirements: JSON.stringify([
        "3+ years building full-stack applications with React, Node.js, and TypeScript.",
        "Experience designing and consuming GraphQL schemas and relational SQL databases.",
        "Understanding of real-time protocols like WebSockets or WebRTC.",
      ]),
      benefits: JSON.stringify([
        "Top-tier compensation package including RSUs and wellness stipends.",
        "On-site gourmet meals, free transit, and comprehensive family care benefits.",
      ]),
      requiredSkills: JSON.stringify(["React", "Node.js", "GraphQL", "PostgreSQL", "TypeScript"]),
      status: "ACTIVE",
      featured: true,
    },
  });

  const jobAmazon = await prisma.job.create({
    data: {
      id: "job-amazon-backend",
      companyId: recruiterCompany.id,
      title: "Backend Developer",
      department: "AWS Core Infrastructure",
      type: "Remote · Full-time",
      experienceLevel: "Mid-Level",
      location: "Seattle, WA / Remote",
      salaryRange: "$100k - $140k",
      description:
        "Architect resilient microservices and distributed storage engines powering AWS customers globally.",
      requirements: JSON.stringify([
        "4+ years backend systems development with Go, Node.js, or Java.",
        "Proficiency in PostgreSQL, Redis caching, and asynchronous message queues.",
      ]),
      benefits: JSON.stringify([
        "Generous 401k match, health benefits, and Amazon employee discounts.",
      ]),
      requiredSkills: JSON.stringify(["Node.js", "PostgreSQL", "AWS", "Docker", "Redis"]),
      status: "ACTIVE",
      featured: false,
    },
  });

  const jobFigma = await prisma.job.create({
    data: {
      id: "job-figma-designer",
      companyId: recruiterCompany.id,
      title: "UI/UX Designer",
      department: "Design Systems",
      type: "Remote · Full-time",
      experienceLevel: "Senior",
      location: "San Francisco, CA / Remote",
      salaryRange: "$95k - $135k",
      description:
        "Help evolve our glassmorphism design language, tokens, and multi-platform component ecosystems.",
      requirements: JSON.stringify([
        "Portfolio showcasing world-class UI design, prototyping, and complex web applications.",
        "Mastery of Figma components, auto-layout, design tokens, and user testing.",
      ]),
      benefits: JSON.stringify([
        "Competitive salary, generous equity, wellness perks, and flexible vacation.",
      ]),
      requiredSkills: JSON.stringify(["Figma", "Design Systems", "UI/UX", "Prototyping", "Glassmorphism"]),
      status: "ACTIVE",
      featured: true,
    },
  });

  const jobNetflix = await prisma.job.create({
    data: {
      id: "job-netflix-data",
      companyId: recruiterCompany.id,
      title: "Data Analyst",
      department: "Streaming Content Analytics",
      type: "Hybrid · Full-time",
      experienceLevel: "Mid-Level",
      location: "Los Gatos, CA",
      salaryRange: "$85k - $120k",
      description:
        "Transform viewer behavior metrics into actionable content licensing and algorithmic recommendations.",
      requirements: JSON.stringify([
        "Strong SQL proficiency, data modeling, and Python/R for statistical modeling.",
        "Experience building interactive dashboards in Tableau or Looker.",
      ]),
      benefits: JSON.stringify([
        "Industry-leading freedom & responsibility compensation model.",
      ]),
      requiredSkills: JSON.stringify(["SQL", "Python", "Tableau", "Data Analysis", "ETL"]),
      status: "ACTIVE",
      featured: false,
    },
  });

  // 5. Create Resume Analysis for John Doe vs Google Senior Frontend Role (Score: 78% as in blueprint)
  await prisma.resumeAnalysis.create({
    data: {
      resumeId: candidateResume.id,
      jobId: jobGoogle.id,
      overallScore: 78,
      skillsMatchScore: 88,
      experienceScore: 80,
      projectsScore: 75,
      educationScore: 70,
      strengths: JSON.stringify([
        "Relevant React experience (5+ years in production apps)",
        "Projects demonstrate complex API integration and state management",
        "Strong TypeScript foundation matching the job's core tech stack",
        "Proven performance optimization with measurable metrics (42% TTFB/LCP reduction)",
      ]),
      missingSkills: JSON.stringify([
        "Automated testing (mention specific tools like Playwright or Cypress)",
        "Advanced SQL (database query optimization not prominent)",
        "Kubernetes or container orchestration basics",
      ]),
      suggestions: JSON.stringify([
        "Add measurable business outcomes to project descriptions (e.g., conversion or retention lift)",
        "Include testing tools used (Vitest, Playwright, Jest) in your prominent skills summary",
        "Clarify experience with Next.js Server Components and App Router data fetching paradigms",
      ]),
      jobMatchExplanation:
        "Strong alignment with React, Next.js, and modern CSS requirements. Adding automated e2e testing examples will elevate your candidacy into the top 5% of applicants.",
    },
  });

  // 6. Create John's Applications (matching panel 4 Application Tracker in blueprint)
  await prisma.application.create({
    data: {
      candidateId: candidateUser.id,
      jobId: jobGoogle.id,
      resumeId: candidateResume.id,
      status: "INTERVIEW",
      matchScore: 78,
      coverLetter: "I have followed Google Cloud Console's evolution closely and would love to bring my React and performance engineering experience to the team.",
      appliedAt: new Date("2026-04-15T10:30:00Z"),
    },
  });

  await prisma.application.create({
    data: {
      candidateId: candidateUser.id,
      jobId: jobMeta.id,
      resumeId: candidateResume.id,
      status: "APPLIED",
      matchScore: 82,
      appliedAt: new Date("2026-04-12T14:15:00Z"),
    },
  });

  await prisma.application.create({
    data: {
      candidateId: candidateUser.id,
      jobId: jobAmazon.id,
      resumeId: candidateResume.id,
      status: "IN_REVIEW",
      matchScore: 68,
      appliedAt: new Date("2026-04-10T09:00:00Z"),
    },
  });

  await prisma.application.create({
    data: {
      candidateId: candidateUser.id,
      jobId: jobFigma.id,
      resumeId: candidateResume.id,
      status: "SHORTLISTED",
      matchScore: 74,
      appliedAt: new Date("2026-04-08T16:45:00Z"),
    },
  });

  await prisma.application.create({
    data: {
      candidateId: candidateUser.id,
      jobId: jobNetflix.id,
      resumeId: candidateResume.id,
      status: "REJECTED",
      matchScore: 52,
      appliedAt: new Date("2026-04-05T11:20:00Z"),
    },
  });

  // 7. Create Other Candidates for Recruiter Dashboard (Alex Carter, Priya Sharma, Rahul Mehta, Emily Davis, James Wilson)
  const otherCandidates = [
    {
      id: "candidate-alex-carter",
      name: "Alex Carter",
      email: "alex.carter@example.com",
      role: "Frontend Developer",
      jobId: jobGoogle.id,
      status: "SHORTLISTED",
      score: 85,
      date: new Date("2026-04-15T09:15:00Z"),
    },
    {
      id: "candidate-priya-sharma",
      name: "Priya Sharma",
      email: "priya.sharma@example.com",
      role: "Full Stack Developer",
      jobId: jobMeta.id,
      status: "INTERVIEW",
      score: 91,
      date: new Date("2026-04-14T11:45:00Z"),
    },
    {
      id: "candidate-rahul-mehta",
      name: "Rahul Mehta",
      email: "rahul.mehta@example.com",
      role: "Backend Developer",
      jobId: jobAmazon.id,
      status: "APPLIED",
      score: 72,
      date: new Date("2026-04-12T16:20:00Z"),
    },
    {
      id: "candidate-emily-davis",
      name: "Emily Davis",
      email: "emily.davis@example.com",
      role: "UI/UX Designer",
      jobId: jobFigma.id,
      status: "IN_REVIEW",
      score: 88,
      date: new Date("2026-04-10T13:00:00Z"),
    },
    {
      id: "candidate-james-wilson",
      name: "James Wilson",
      email: "james.wilson@example.com",
      role: "Data Analyst",
      jobId: jobNetflix.id,
      status: "REJECTED",
      score: 48,
      date: new Date("2026-04-08T15:30:00Z"),
    },
  ];

  for (const cand of otherCandidates) {
    const user = await prisma.user.create({
      data: {
        id: cand.id,
        email: cand.email,
        name: cand.name,
        role: "CANDIDATE",
        avatar: `https://images.unsplash.com/photo-${cand.name === "Priya Sharma" || cand.name === "Emily Davis" ? "1494790108377-be9c29b29330" : "1507003211169-0a1dd7228f2d"}?auto=format&fit=crop&w=250&q=80`,
      },
    });

    const resume = await prisma.resume.create({
      data: {
        id: `resume-${cand.id}`,
        userId: user.id,
        fileName: `${cand.name.replace(" ", "_")}_Resume.pdf`,
        extractedText: `${cand.name} - ${cand.role}. Experienced software professional with a passion for high performance and quality code.`,
        parsedSkills: JSON.stringify(["TypeScript", "React", "Node.js", "SQL"]),
      },
    });

    await prisma.application.create({
      data: {
        candidateId: user.id,
        jobId: cand.jobId,
        resumeId: resume.id,
        status: cand.status,
        matchScore: cand.score,
        appliedAt: cand.date,
      },
    });
  }

  // 8. Create Saved Jobs for John Doe
  await prisma.savedJob.create({
    data: {
      userId: candidateUser.id,
      jobId: jobGoogle.id,
    },
  });
  await prisma.savedJob.create({
    data: {
      userId: candidateUser.id,
      jobId: jobMeta.id,
    },
  });

  // 9. Create Notifications
  await prisma.notification.create({
    data: {
      userId: candidateUser.id,
      title: "Interview Scheduled!",
      message: "Google invited you to a technical interview for Senior Frontend Developer.",
      type: "INTERVIEW_INVITE",
      link: "/candidate/applications",
    },
  });
  await prisma.notification.create({
    data: {
      userId: candidateUser.id,
      title: "Resume Analysis Ready",
      message: "Your resume scored 78% for the Senior Frontend Developer position.",
      type: "AI_ALERT",
      link: "/candidate/resume",
    },
  });
  await prisma.notification.create({
    data: {
      userId: recruiterUser.id,
      title: "New Application Received",
      message: "Alex Carter submitted an application for Senior Frontend Developer.",
      type: "APPLICATION_STATUS",
      link: "/recruiter/applicants",
    },
  });

  console.log("Database seeded successfully with authentic blueprint data!");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
