"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { GlassCard } from "@/components/glass-card";
import { ApplicationData } from "@/types";
import { getStatusColor, formatDate } from "@/lib/utils";
import {
  Send,
  Calendar,
  Building,
  CheckCircle2,
  Clock,
  ExternalLink,
  Sparkles,
  Filter,
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function ApplicationsTrackerPage() {
  const [applications, setApplications] = useState<ApplicationData[]>([]);
  const [activeFilter, setActiveFilter] = useState<string>("ALL");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchApplications();
  }, []);

  const fetchApplications = async () => {
    try {
      const res = await fetch("/api/applications/me");
      if (res.ok) {
        const data = await res.json();
        setApplications(data.applications || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const counts = {
    ALL: applications.length,
    APPLIED: applications.filter((a) => a.status === "APPLIED").length,
    IN_REVIEW: applications.filter((a) => a.status === "IN_REVIEW").length,
    INTERVIEW: applications.filter((a) => a.status === "INTERVIEW").length,
    OFFERED: applications.filter((a) => a.status === "OFFERED").length,
    REJECTED: applications.filter((a) => a.status === "REJECTED").length,
  };

  const filteredApps =
    activeFilter === "ALL"
      ? applications
      : applications.filter((a) => a.status === activeFilter);

  return (
    <div className="space-y-8">
      {/* Page Header (Panel 4) */}
      <div className="space-y-1">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          My Applications
        </h1>
        <p className="text-xs sm:text-sm text-slate-400">
          Track the real-time status of your job applications across hiring pipelines.
        </p>
      </div>

      {/* Filter Tabs matching Panel 4 (All, Applied, Interview, Offer, Rejected) */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 rounded-2xl bg-white/5 border border-white/10 w-fit">
        {[
          { id: "ALL", label: `All (${counts.ALL})` },
          { id: "APPLIED", label: `Applied (${counts.APPLIED})` },
          { id: "INTERVIEW", label: `Interview (${counts.INTERVIEW})` },
          { id: "IN_REVIEW", label: `In Review (${counts.IN_REVIEW})` },
          { id: "OFFERED", label: `Offer (${counts.OFFERED})` },
          { id: "REJECTED", label: `Rejected (${counts.REJECTED})` },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveFilter(tab.id)}
            className={cn(
              "px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all",
              activeFilter === tab.id
                ? "bg-violet-600 text-white shadow-md shadow-violet-500/25"
                : "text-slate-400 hover:text-white hover:bg-white/5"
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Applications Table / Cards (Panel 4) */}
      <GlassCard className="p-0 overflow-hidden border-white/15">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-white/10 bg-white/[0.02] text-slate-400">
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px]">
                  Job Position
                </th>
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px]">
                  Company
                </th>
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px]">
                  Status
                </th>
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px]">
                  Applied On
                </th>
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px] text-right">
                  Match Score
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {loading ? (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-slate-400">
                    <div className="inline-block w-6 h-6 border-2 border-violet-500 border-t-transparent rounded-full animate-spin mb-2" />
                    <p>Loading application data...</p>
                  </td>
                </tr>
              ) : filteredApps.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-slate-400">
                    No applications match the selected filter.
                  </td>
                </tr>
              ) : (
                filteredApps.map((app) => {
                  const statusColors = getStatusColor(app.status);
                  return (
                    <tr
                      key={app.id}
                      className="hover:bg-white/[0.03] transition-colors group"
                    >
                      <td className="py-4 px-6 font-medium text-white">
                        <Link
                          href={`/jobs/${app.jobId}`}
                          className="hover:text-aqua transition-colors flex items-center gap-1.5"
                        >
                          {app.job?.title || "Software Engineer"}
                          <ExternalLink className="w-3 h-3 text-slate-500 group-hover:text-aqua" />
                        </Link>
                      </td>
                      <td className="py-4 px-6 text-slate-300">
                        <div className="flex items-center gap-2">
                          <Building className="w-3.5 h-3.5 text-slate-400" />
                          <span>{app.job?.company?.name || "TechCorp"}</span>
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <span
                          className={cn(
                            "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold border",
                            statusColors.bg,
                            statusColors.text,
                            statusColors.border
                          )}
                        >
                          <span className="w-1.5 h-1.5 rounded-full bg-current" />
                          {app.status.replace("_", " ")}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-slate-400 font-mono text-[11px]">
                        {formatDate(app.appliedAt)}
                      </td>
                      <td className="py-4 px-6 text-right">
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-aqua/10 border border-aqua/30 text-aqua font-bold text-[11px]">
                          <Sparkles className="w-3 h-3" />
                          {app.matchScore || 78}%
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  );
}
