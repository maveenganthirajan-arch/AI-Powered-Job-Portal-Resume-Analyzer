import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { getCandidateApplications } from "@/services/applications";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const applications = await getCandidateApplications(user.id);
    return NextResponse.json({ applications });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
