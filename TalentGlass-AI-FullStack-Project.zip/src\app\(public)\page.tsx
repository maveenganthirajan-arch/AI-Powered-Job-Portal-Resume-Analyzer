import React from "react";
import Link from "next/link";
import { db } from "@/lib/db";
import { JobCard } from "@/components/job-card";
import { GlassCard } from "@/components/glass-card";
import { ScoreCard } from "@/components/score-card";
import {
  Sparkles,
  Search,
  MapPin,
  ArrowRight,
  TrendingUp,
  Cpu,
  Layers,
  ShieldCheck,
  CheckCircle2,
  Users,
  Briefcase,
  FileCheck,
} from "lucide-react";

export const revalidate = 0; // Dynamic server rendering

export default async function HomePage() {
  const jobs = await db.job.findMany({
    where: { status: "ACTIVE" },
    include: { company: true },
    take: 6,
    orderBy: { featured: "desc" },
  });

  const parsedJobs = jobs.map((job) => ({
    ...job,
    requirements: JSON.parse(job.requirements || "[]"),
    benefits: JSON.parse(job.benefits || "[]"),
    requiredSkills: JSON.parse(job.requiredSkills || "[]"),
    status: job.status as any,
  }));

  const categories = [
    { name: "Technology", count: "12k+ jobs", icon: Cpu, href: "/jobs?query=Engineer" },
    { name: "Marketing", count: "4k+ jobs", icon: TrendingUp, href: "/jobs?query=Marketing" },
    { name: "Design", count: "6k+ jobs", icon: Layers, href: "/jobs?query=Designer" },
    { name: "Finance", count: "4k+ jobs", icon: ShieldCheck, href: "/jobs?query=Finance" },
    { name: "Data & AI", count: "8k+ jobs", icon: Sparkles, href: "/jobs?query=Data" },
  ];

  return (
    <div className="space-y-20 pb-16">
      {/* Hero Section (Matching Panel 2 "Find Your Dream Job") */}
      <section className="relative pt-12 pb-16 md:pt-20 md:pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center">
        {/* Glow backdrop */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-3xl h-64 bg-gradient-to-r from-violet-600/20 via-aqua/15 to-violet-600/20 blur-3xl rounded-full pointer-events-none -z-10" />

        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-semibold text-aqua mb-6 shadow-sm">
          <Sparkles className="w-3.5 h-3.5" />
          <span>TalentGlass AI · 2026 Full-Stack Project Blueprint</span>
        </div>

        <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-white tracking-tight leading-tight max-w-4xl mx-auto">
          Find Your Dream Job with{" "}
          <span className="bg-gradient-to-r from-violet-400 via-white to-aqua bg-clip-text text-transparent">
            Glassmorphic AI Precision
          </span>
        </h1>

        <p className="mt-5 text-base sm:text-lg text-slate-300 max-w-2xl mx-auto font-normal leading-relaxed">
          Get matched with opportunities that fit your exact skills and goals. Upload your resume for real-time ATS match explanations, or publish jobs as a recruiter.
        </p>

        {/* Hero Interactive Search Bar (Matching Panel 2) */}
        <div className="mt-10 max-w-4xl mx-auto">
          <form
            action="/jobs"
            method="GET"
            className="p-2 sm:p-3 glass-card border border-white/20 shadow-2xl flex flex-col md:flex-row items-center gap-3"
          >
            <div className="flex-1 w-full flex items-center gap-3 px-4 py-2.5 bg-white/5 rounded-xl border border-white/10">
              <Search className="w-4 h-4 text-slate-400 shrink-0" />
              <input
                type="text"
                name="query"
                placeholder="Job title, skills, or keywords (e.g. React, Senior)..."
                className="w-full bg-transparent text-sm text-white placeholder-slate-400 focus:outline-none"
              />
            </div>

            <div className="w-full md:w-64 flex items-center gap-3 px-4 py-2.5 bg-white/5 rounded-xl border border-white/10">
              <MapPin className="w-4 h-4 text-aqua shrink-0" />
              <input
                type="text"
                name="location"
                placeholder="Location (e.g. Remote, CA)..."
                className="w-full bg-transparent text-sm text-white placeholder-slate-400 focus:outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full md:w-auto px-8 py-3 rounded-xl bg-gradient-to-r from-violet-600 via-violet-500 to-aqua text-white text-sm font-bold shadow-lg shadow-violet-500/25 hover:opacity-95 transition-all shrink-0 flex items-center justify-center gap-2"
            >
              <Search className="w-4 h-4" />
              Search
            </button>
          </form>
        </div>

        {/* Popular Categories (Matching Panel 2) */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
          <span className="text-xs text-slate-400 font-medium mr-1">Popular:</span>
          {categories.map((cat) => {
            const Icon = cat.icon;
            return (
              <Link
                key={cat.name}
                href={cat.href}
                className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-violet-500/30 text-xs font-medium text-slate-300 hover:text-white transition-all shadow-sm"
              >
                <Icon className="w-3.5 h-3.5 text-aqua" />
                <span>{cat.name}</span>
                <span className="text-[10px] text-slate-400">({cat.count})</span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Featured Jobs Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-aqua mb-1">
              <Briefcase className="w-3.5 h-3.5" />
              Verified Openings
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              Featured Opportunities
            </h2>
          </div>
          <Link
            href="/jobs"
            className="text-xs font-semibold text-aqua hover:text-aqua-bright flex items-center gap-1 group"
          >
            Explore all openings
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {parsedJobs.map((job) => (
            <JobCard key={job.id} job={job} />
          ))}
        </div>
      </section>

      {/* AI Resume Analyzer Feature Showcase (Matching Panel 5) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <GlassCard className="p-8 md:p-12 relative overflow-hidden border-violet-500/30 shadow-[0_0_50px_rgba(124,92,252,0.12)]">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-aqua/10 border border-aqua/30 text-xs font-semibold text-aqua">
                <Sparkles className="w-3.5 h-3.5" />
                AI Resume Match & ATS Simulation
              </div>

              <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                Benchmark Your Resume Against Any Job in Seconds
              </h2>

              <p className="text-sm text-slate-300 leading-relaxed max-w-xl">
                TalentGlass AI parses your skills, evaluates relevant experience, analyzes project impact, and calculates an explainable 40/25/20/15 weighted match score with actionable tips.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="flex items-start gap-2.5 text-xs text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-aqua shrink-0 mt-0.5" />
                  <span>Transparent 40% Skills & 25% Experience weighting</span>
                </div>
                <div className="flex items-start gap-2.5 text-xs text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-aqua shrink-0 mt-0.5" />
                  <span>Actionable missing skills and suggestions</span>
                </div>
                <div className="flex items-start gap-2.5 text-xs text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-aqua shrink-0 mt-0.5" />
                  <span>Zero-bias scoring protecting candidate privacy</span>
                </div>
                <div className="flex items-start gap-2.5 text-xs text-slate-300">
                  <CheckCircle2 className="w-4 h-4 text-aqua shrink-0 mt-0.5" />
                  <span>One-click direct job application with resume preview</span>
                </div>
              </div>

              <div className="pt-4 flex flex-wrap gap-4">
                <Link
                  href="/candidate/resume"
                  className="px-6 py-3 rounded-xl bg-gradient-to-r from-violet-600 to-aqua text-white text-xs font-bold shadow-lg shadow-violet-500/25 hover:opacity-95 transition-all flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  Try Resume Analyzer
                </Link>
                <Link
                  href="/blueprint"
                  className="px-6 py-3 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold border border-white/10 transition-colors flex items-center gap-2"
                >
                  <Layers className="w-4 h-4 text-violet-400" />
                  View 2026 Architecture Blueprint
                </Link>
              </div>
            </div>

            {/* Circular Gauge Showcase */}
            <div className="lg:col-span-5 flex justify-center">
              <div className="p-6 rounded-3xl bg-midnight-900/80 border border-white/15 shadow-2xl w-full max-w-sm">
                <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider text-center mb-4">
                  Live Match Simulation
                </h4>
                <ScoreCard
                  score={78}
                  label="Good Match"
                  size="lg"
                  showBreakdown={true}
                  breakdown={{
                    skillsMatch: 88,
                    experience: 80,
                    projects: 75,
                    education: 70,
                  }}
                />
              </div>
            </div>
          </div>
        </GlassCard>
      </section>

      {/* Recruiter & Candidate Portals Teaser */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Candidate Card */}
          <GlassCard className="p-8 space-y-5 border-white/10">
            <div className="w-12 h-12 rounded-2xl bg-violet-600/20 border border-violet-500/30 flex items-center justify-center text-violet-400">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-white">For Job Seekers & Engineers</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Track submitted applications in real time through APPLIED, IN_REVIEW, SHORTLISTED, and INTERVIEW stages. Store multiple tailored resumes in your private library.
            </p>
            <div className="pt-2">
              <Link
                href="/candidate/dashboard"
                className="text-xs font-semibold text-aqua hover:underline flex items-center gap-1.5"
              >
                Go to Candidate Dashboard <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </GlassCard>

          {/* Recruiter Card */}
          <GlassCard className="p-8 space-y-5 border-white/10">
            <div className="w-12 h-12 rounded-2xl bg-aqua/20 border border-aqua/30 flex items-center justify-center text-aqua">
              <Briefcase className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-white">For Recruiters & Hiring Managers</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Publish rich job posts, inspect applicant resumes with AI Match scores, advance or reject candidates with 1-click status controls, and schedule interviews.
            </p>
            <div className="pt-2">
              <Link
                href="/recruiter/dashboard"
                className="text-xs font-semibold text-aqua hover:underline flex items-center gap-1.5"
              >
                Go to Recruiter Dashboard <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </GlassCard>
        </div>
      </section>
    </div>
  );
}
