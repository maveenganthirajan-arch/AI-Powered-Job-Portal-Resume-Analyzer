import fs from "fs/promises";
import path from "path";
import crypto from "crypto";

const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads", "resumes");

export interface StoredFile {
  storageKey: string;
  fileName: string;
  fileUrl: string;
  sizeBytes: number;
}

export async function saveResumeFile(
  fileBuffer: Buffer,
  originalName: string,
  mimeType: string
): Promise<StoredFile> {
  // Ensure target folder exists
  await fs.mkdir(UPLOAD_DIR, { recursive: true });

  const randomHash = crypto.randomBytes(8).toString("hex");
  const sanitizedName = originalName.replace(/[^a-zA-Z0-9.-]/g, "_");
  const fileName = `${Date.now()}_${randomHash}_${sanitizedName}`;
  const filePath = path.join(UPLOAD_DIR, fileName);

  await fs.writeFile(filePath, fileBuffer);

  return {
    storageKey: `resumes/${fileName}`,
    fileName: originalName,
    fileUrl: `/uploads/resumes/${fileName}`,
    sizeBytes: fileBuffer.length,
  };
}

export async function deleteResumeFile(storageKey: string): Promise<boolean> {
  try {
    const fileName = path.basename(storageKey);
    const filePath = path.join(UPLOAD_DIR, fileName);
    await fs.unlink(filePath);
    return true;
  } catch (e) {
    return false;
  }
}
