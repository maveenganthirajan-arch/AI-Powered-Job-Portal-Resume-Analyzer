"use client";

import React, { useState } from "react";
import { GlassCard } from "./glass-card";
import {
  Layers,
  Database,
  Cpu,
  Server,
  Cloud,
  FileText,
  CheckCircle2,
  GitBranch,
  Calendar,
  Sparkles,
  ArrowRight,
  ShieldAlert,
  HardDrive,
  Users,
  Search,
  Code2,
} from "lucide-react";
import { cn } from "@/lib/utils";

export function InteractiveBlueprint() {
  const [activeTab, setActiveTab] = useState<
    "architecture" | "er" | "pipeline" | "matching" | "timeline" | "deployment"
  >("architecture");

  return (
    <div className="space-y-8">
      {/* Navigation tabs */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 rounded-2xl bg-white/5 border border-white/10 w-fit">
        <button
          onClick={() => setActiveTab("architecture")}
          className={cn(
            "px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-2",
            activeTab === "architecture"
              ? "bg-violet-600 text-white shadow-md shadow-violet-500/25"
              : "text-slate-400 hover:text-white hover:bg-white/5"
          )}
        >
          <Server className="w-3.5 h-3.5" />
          7. System Architecture
        </button>

        <button
          onClick={() => setActiveTab("er")}
          className={cn(
            "px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-2",
            activeTab === "er"
              ? "bg-violet-600 text-white shadow-md shadow-violet-500/25"
              : "text-slate-400 hover:text-white hover:bg-white/5"
          )}
        >
          <Database className="w-3.5 h-3.5" />
          8. Database ER Diagram
        </button>

        <button
          onClick={() => setActiveTab("pipeline")}
          className={cn(
            "px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-2",
            activeTab === "pipeline"
              ? "bg-violet-600 text-white shadow-md shadow-violet-500/25"
              : "text-slate-400 hover:text-white hover:bg-white/5"
          )}
        >
          <FileText className="w-3.5 h-3.5" />
          9-10. Resume Analysis Flow
        </button>

        <button
          onClick={() => setActiveTab("matching")}
          className={cn(
            "px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-2",
            activeTab === "matching"
              ? "bg-aqua text-midnight-950 font-bold shadow-md shadow-aqua/25"
              : "text-slate-400 hover:text-white hover:bg-white/5"
          )}
        >
          <Sparkles className="w-3.5 h-3.5" />
          11. AI Matching Logic
        </button>

        <button
          onClick={() => setActiveTab("timeline")}
          className={cn(
            "px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-2",
            activeTab === "timeline"
              ? "bg-violet-600 text-white shadow-md shadow-violet-500/25"
              : "text-slate-400 hover:text-white hover:bg-white/5"
          )}
        >
          <Calendar className="w-3.5 h-3.5" />
          12. Development Timeline
        </button>

        <button
          onClick={() => setActiveTab("deployment")}
          className={cn(
            "px-4 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-2",
            activeTab === "deployment"
              ? "bg-violet-600 text-white shadow-md shadow-violet-500/25"
              : "text-slate-400 hover:text-white hover:bg-white/5"
          )}
        >
          <Cloud className="w-3.5 h-3.5" />
          13. Deployment Blueprint
        </button>
      </div>

      {/* Tab 1: System Architecture Diagram */}
      {activeTab === "architecture" && (
        <GlassCard className="p-8 space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div>
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <Server className="w-5 h-5 text-violet-400" />
                Panel 7: System Architecture Diagram
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Unified Next.js 14 App Router full-stack runtime with Server Actions, REST Route Handlers, and Edge Orchestration.
              </p>
            </div>
            <span className="px-3 py-1 rounded-full text-xs font-semibold bg-violet-500/20 text-violet-300 border border-violet-500/30">
              Modern 2026 Micro-Engine
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
            {/* Layer 1: Clients */}
            <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-4">
              <div className="flex items-center gap-2 text-violet-400 font-semibold text-sm">
                <Users className="w-4 h-4" />
                Client Tier
              </div>
              <div className="p-3.5 rounded-xl bg-midnight-900/80 border border-white/10">
                <h5 className="text-xs font-semibold text-white">Candidate Browser</h5>
                <p className="text-[11px] text-slate-400">Search, resume scan, match gauge, tracker</p>
              </div>
              <div className="p-3.5 rounded-xl bg-midnight-900/80 border border-white/10">
                <h5 className="text-xs font-semibold text-white">Recruiter Browser</h5>
                <p className="text-[11px] text-slate-400">Job publisher, pipeline kanban, candidate reviews</p>
              </div>
              <div className="p-3.5 rounded-xl bg-midnight-900/80 border border-white/10">
                <h5 className="text-xs font-semibold text-white">Responsive Devices</h5>
                <p className="text-[11px] text-slate-400">Tailwind Glassmorphic mobile layout</p>
              </div>
            </div>

            {/* Layer 2: Next.js Orchestration */}
            <div className="p-5 rounded-2xl bg-gradient-to-b from-violet-600/10 to-transparent border border-violet-500/30 space-y-4">
              <div className="flex items-center gap-2 text-aqua font-semibold text-sm">
                <Cpu className="w-4 h-4" />
                Next.js Application Core
              </div>
              <div className="p-3.5 rounded-xl bg-midnight-900/90 border border-violet-500/20">
                <h5 className="text-xs font-semibold text-aqua">App Router & Server Components</h5>
                <p className="text-[11px] text-slate-300">Fast SSR + React 18 hydration</p>
              </div>
              <div className="p-3.5 rounded-xl bg-midnight-900/90 border border-violet-500/20">
                <h5 className="text-xs font-semibold text-aqua">API Route Handlers</h5>
                <p className="text-[11px] text-slate-300">Zod validated endpoints for Auth, Jobs, Resumes</p>
              </div>
              <div className="p-3.5 rounded-xl bg-midnight-900/90 border border-violet-500/20">
                <h5 className="text-xs font-semibold text-aqua">AI Orchestration Engine</h5>
                <p className="text-[11px] text-slate-300">Semantic scoring, text normalization, prompt defense</p>
              </div>
            </div>

            {/* Layer 3: Persistence & Providers */}
            <div className="p-5 rounded-2xl bg-white/5 border border-white/10 space-y-4">
              <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
                <Database className="w-4 h-4" />
                Storage & External Services
              </div>
              <div className="p-3.5 rounded-xl bg-midnight-900/80 border border-white/10">
                <h5 className="text-xs font-semibold text-white">PostgreSQL / Prisma DB</h5>
                <p className="text-[11px] text-slate-400">Relational schema, 10 models, indexing</p>
              </div>
              <div className="p-3.5 rounded-xl bg-midnight-900/80 border border-white/10">
                <h5 className="text-xs font-semibold text-white">Private Storage</h5>
                <p className="text-[11px] text-slate-400">Encrypted resume files (S3 / Local adapter)</p>
              </div>
              <div className="p-3.5 rounded-xl bg-midnight-900/80 border border-white/10">
                <h5 className="text-xs font-semibold text-white">AI Provider (LLM API)</h5>
                <p className="text-[11px] text-slate-400">Gemini 1.5 Flash / OpenAI structured JSON</p>
              </div>
            </div>
          </div>
        </GlassCard>
      )}

      {/* Tab 2: Database ER Diagram */}
      {activeTab === "er" && (
        <GlassCard className="p-8 space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div>
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <Database className="w-5 h-5 text-aqua" />
                Panel 8: Database ER Diagram & Relational Mapping
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Strict foreign keys, cascade deletes, unique candidate application indexing, and structured analysis versioning.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
            {/* User Model */}
            <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-xs space-y-2">
              <div className="font-bold text-white flex items-center justify-between">
                <span>User</span>
                <span className="text-[10px] text-slate-400">Core</span>
              </div>
              <div className="space-y-1 text-slate-300 font-mono text-[11px]">
                <div className="text-violet-400">id (PK, cuid)</div>
                <div>name (String)</div>
                <div className="text-aqua">email (String, Unique)</div>
                <div>role (CANDIDATE | RECRUITER)</div>
                <div>avatar (String?)</div>
              </div>
            </div>

            {/* CandidateProfile */}
            <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-xs space-y-2">
              <div className="font-bold text-white flex items-center justify-between">
                <span>CandidateProfile</span>
                <span className="text-[10px] text-slate-400">1:1 User</span>
              </div>
              <div className="space-y-1 text-slate-300 font-mono text-[11px]">
                <div className="text-violet-400">id (PK)</div>
                <div className="text-amber-400">userId (FK -&gt; User.id)</div>
                <div>headline (String?)</div>
                <div>location (String?)</div>
                <div>skills (JSON Array)</div>
              </div>
            </div>

            {/* Company */}
            <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-xs space-y-2">
              <div className="font-bold text-white flex items-center justify-between">
                <span>Company</span>
                <span className="text-[10px] text-slate-400">Recruiter Org</span>
              </div>
              <div className="space-y-1 text-slate-300 font-mono text-[11px]">
                <div className="text-violet-400">id (PK)</div>
                <div className="text-amber-400">ownerId (FK -&gt; User.id)</div>
                <div>name (String)</div>
                <div>description (String)</div>
                <div>website (String)</div>
              </div>
            </div>

            {/* Job */}
            <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-xs space-y-2">
              <div className="font-bold text-white flex items-center justify-between">
                <span>Job</span>
                <span className="text-[10px] text-slate-400">1:N Company</span>
              </div>
              <div className="space-y-1 text-slate-300 font-mono text-[11px]">
                <div className="text-violet-400">id (PK)</div>
                <div className="text-amber-400">companyId (FK)</div>
                <div>title (String)</div>
                <div>salaryRange (String)</div>
                <div>requiredSkills (JSON)</div>
                <div>status (ACTIVE | CLOSED)</div>
              </div>
            </div>

            {/* Application */}
            <div className="p-4 rounded-xl bg-white/5 border border-aqua/30 text-xs space-y-2 shadow-[0_0_20px_rgba(53,214,197,0.1)]">
              <div className="font-bold text-aqua flex items-center justify-between">
                <span>Application</span>
                <span className="text-[10px] text-aqua">Joint Junction</span>
              </div>
              <div className="space-y-1 text-slate-300 font-mono text-[11px]">
                <div className="text-violet-400">id (PK)</div>
                <div className="text-amber-400">candidateId (FK)</div>
                <div className="text-amber-400">jobId (FK)</div>
                <div className="text-amber-400">resumeId (FK)</div>
                <div className="text-emerald-400">matchScore (Int)</div>
                <div>status (APPLIED..REJECTED)</div>
              </div>
            </div>

            {/* Resume & Analysis */}
            <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-xs space-y-2">
              <div className="font-bold text-white flex items-center justify-between">
                <span>ResumeAnalysis</span>
                <span className="text-[10px] text-slate-400">AI Report</span>
              </div>
              <div className="space-y-1 text-slate-300 font-mono text-[11px]">
                <div className="text-violet-400">id (PK)</div>
                <div className="text-amber-400">resumeId (FK)</div>
                <div className="text-emerald-400">overallScore (Int 0-100)</div>
                <div>strengths (JSON)</div>
                <div>missingSkills (JSON)</div>
                <div>suggestions (JSON)</div>
              </div>
            </div>
          </div>
        </GlassCard>
      )}

      {/* Tab 3: Resume Analysis Flow */}
      {activeTab === "pipeline" && (
        <GlassCard className="p-8 space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div>
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <FileText className="w-5 h-5 text-aqua" />
                Panel 9 & 10: Candidate Flow & Resume Analysis Pipeline
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                6-stage asynchronous evaluation sequence from upload to explainable report generation.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 pt-2">
            {[
              {
                num: 1,
                title: "Upload & Validate",
                desc: "Check PDF/DOCX MIME type, enforce 5MB ceiling, generate crypto hash.",
              },
              {
                num: 2,
                title: "Extract Text",
                desc: "Strip formatting artifacts, extract raw strings from binary document buffer.",
              },
              {
                num: 3,
                title: "Normalize Content",
                desc: "Remove escape noise, whitespace compress, identify skills dictionary hits.",
              },
              {
                num: 4,
                title: "LLM Analysis",
                desc: "Wrap in untrusted delimiters, inject strict structured JSON prompt schema.",
              },
              {
                num: 5,
                title: "Zod Verification",
                desc: "Ensure score bounds (0-100), array types, and prevent hallucinations.",
              },
              {
                num: 6,
                title: "Save & Show",
                desc: "Store report in SQLite/Postgres and render interactive radial glass gauge.",
              },
            ].map((step) => (
              <div
                key={step.num}
                className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2 flex flex-col justify-between"
              >
                <div>
                  <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-violet-600 to-aqua flex items-center justify-center text-xs font-bold text-white">
                    {step.num}
                  </div>
                  <h4 className="text-xs font-bold text-white mt-3">{step.title}</h4>
                  <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </GlassCard>
      )}

      {/* Tab 4: AI Matching Logic */}
      {activeTab === "matching" && (
        <GlassCard className="p-8 space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div>
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-aqua" />
                Panel 11: Explainable AI Matching Formula (100% Total)
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Transparent weighted rubric ensuring ethical, anti-bias, and fully explainable hiring decisions.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center pt-2">
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-white">1. Required Skills Match</span>
                  <span className="font-bold text-aqua">40% Weight</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Exact & semantic intersection of required technologies vs resume extracted skills.
                </p>
                <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                  <div className="h-full bg-aqua w-[40%]" />
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-white">2. Relevant Experience Match</span>
                  <span className="font-bold text-violet-400">25% Weight</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Years of professional production tenure, role seniority, and domain relevance.
                </p>
                <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                  <div className="h-full bg-violet-500 w-[25%]" />
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-white">3. Project Relevance Match</span>
                  <span className="font-bold text-purple-400">20% Weight</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Measurable metrics (e.g. latency drop, user scale, microservices, open source contributions).
                </p>
                <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                  <div className="h-full bg-purple-500 w-[20%]" />
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1.5">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-white">4. Education or Certifications</span>
                  <span className="font-bold text-slate-300">15% Weight</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Degree in CS or STEM, accredited bootcamps, or industry cloud certifications.
                </p>
                <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                  <div className="h-full bg-slate-400 w-[15%]" />
                </div>
              </div>
            </div>

            {/* Visual Ring Representation */}
            <div className="flex flex-col items-center justify-center p-6 rounded-3xl bg-white/[0.03] border border-white/10 text-center">
              <div className="relative flex items-center justify-center h-48 w-48">
                <div className="absolute inset-0 rounded-full border-8 border-violet-500/20" />
                <div className="absolute inset-0 rounded-full border-8 border-aqua border-t-transparent border-r-transparent transform rotate-45" />
                <div className="text-center">
                  <span className="text-4xl font-extrabold text-white">100%</span>
                  <p className="text-[11px] text-slate-400 uppercase tracking-widest mt-0.5">
                    Total Score
                  </p>
                </div>
              </div>
              <p className="text-xs text-slate-400 mt-6 max-w-sm">
                "AI scores are estimates, not guarantees. All components are transparently displayed so candidates and recruiters retain full autonomy."
              </p>
            </div>
          </div>
        </GlassCard>
      )}

      {/* Tab 5: Development Timeline */}
      {activeTab === "timeline" && (
        <GlassCard className="p-8 space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div>
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <Calendar className="w-5 h-5 text-violet-400" />
                Panel 12: Development Timeline & Phased Execution
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Completed 8-phase full-stack blueprint roadmap.
              </p>
            </div>
          </div>

          <div className="space-y-3 pt-2">
            {[
              { phase: "Phase 1: Setup and planning", days: "Days 1–2", status: "Completed", tasks: "Prisma schema, Next.js 14 App Router, TypeScript configs" },
              { phase: "Phase 2: Glassmorphism UI", days: "Days 3–6", status: "Completed", tasks: "Midnight navy palette, custom blur cards, responsive layout" },
              { phase: "Phase 3: Database and authentication", days: "Days 7–10", status: "Completed", tasks: "Prisma client, mock & session auth, seed script with 5 demo roles" },
              { phase: "Phase 4: Jobs and applications", days: "Days 11–15", status: "Completed", tasks: "Search, filter, salary tags, unique application enforcement" },
              { phase: "Phase 5: Resume upload and parsing", days: "Days 16–19", status: "Completed", tasks: "PDF/DOCX extraction, private storage adapter, skills dictionary" },
              { phase: "Phase 6: AI integration", days: "Days 20–23", status: "Completed", tasks: "40/25/20/15 weighted engine, Gemini & OpenAI prompt defense" },
              { phase: "Phase 7: Testing and security", days: "Days 24–26", status: "Completed", tasks: "Zod validation, CORS, sanitized inputs, rate limits" },
              { phase: "Phase 8: Deployment and portfolio", days: "Days 27–30", status: "Production Ready", tasks: "Zero-config local run, Vercel ready, Postgres compatible" },
            ].map((p, idx) => (
              <div
                key={p.phase}
                className="flex items-center justify-between p-3.5 rounded-xl bg-white/5 border border-white/10 text-xs"
              >
                <div className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-full bg-violet-600/30 text-aqua font-bold flex items-center justify-center text-[10px]">
                    {idx + 1}
                  </span>
                  <div>
                    <span className="font-semibold text-white">{p.phase}</span>
                    <span className="text-slate-400 ml-2 hidden sm:inline">({p.tasks})</span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-slate-400 font-mono text-[11px]">{p.days}</span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-medium border border-emerald-500/20 text-[10px]">
                    {p.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </GlassCard>
      )}

      {/* Tab 6: Deployment Blueprint */}
      {activeTab === "deployment" && (
        <GlassCard className="p-8 space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div>
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <Cloud className="w-5 h-5 text-aqua" />
                Panel 13: Production Deployment Blueprint
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Zero-friction local dev transitioning to high-availability managed cloud architecture.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 pt-2">
            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
              <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center text-white">
                <Cloud className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-bold text-white">Vercel Platform</h4>
              <p className="text-[11px] text-slate-400">
                Next.js Edge network, automatic SSL, preview URLs, serverless route handlers.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
              <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center text-aqua">
                <Database className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-bold text-white">Managed PostgreSQL</h4>
              <p className="text-[11px] text-slate-400">
                Supabase / Neon DB with automated connection pooling and Prisma migration.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
              <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center text-violet-400">
                <HardDrive className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-bold text-white">Private File Storage</h4>
              <p className="text-[11px] text-slate-400">
                AWS S3 / Cloudflare R2 bucket with signed URLs for confidential resume files.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
              <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center text-emerald-400">
                <Cpu className="w-4 h-4" />
              </div>
              <h4 className="text-xs font-bold text-white">AI Provider</h4>
              <p className="text-[11px] text-slate-400">
                Google Gemini API / OpenAI API with secure server-side env token storage.
              </p>
            </div>
          </div>
        </GlassCard>
      )}
    </div>
  );
}
