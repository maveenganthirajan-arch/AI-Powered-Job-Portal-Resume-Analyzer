import React from "react";
import Link from "next/link";
import { Sparkles, Heart, Shield, Cpu, Github, ExternalLink } from "lucide-react";

export function Footer() {
  return (
    <footer className="mt-20 border-t border-white/10 bg-midnight-950/80 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand info */}
          <div className="space-y-4 md:col-span-1">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-violet-600 to-aqua shadow-md">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="text-base font-bold text-white tracking-tight">
                TalentGlass <span className="text-aqua font-semibold">AI</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Full-Stack AI-Powered Job Portal & Intelligent Resume Analyzer built on modern Glassmorphism UI principles (2026 Blueprint).
            </p>
            <div className="flex items-center gap-2 text-[11px] text-slate-500">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>All Systems Operational · 2026</span>
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-white mb-3">
              Candidate Platform
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <Link href="/jobs" className="hover:text-aqua transition-colors">
                  Browse Opportunities
                </Link>
              </li>
              <li>
                <Link href="/candidate/resume" className="hover:text-aqua transition-colors">
                  AI Resume Analyzer
                </Link>
              </li>
              <li>
                <Link href="/candidate/dashboard" className="hover:text-aqua transition-colors">
                  Candidate Dashboard
                </Link>
              </li>
              <li>
                <Link href="/candidate/applications" className="hover:text-aqua transition-colors">
                  Application Tracker
                </Link>
              </li>
            </ul>
          </div>

          {/* Recruiter links */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-white mb-3">
              Recruiter Hub
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <Link href="/recruiter/dashboard" className="hover:text-aqua transition-colors">
                  Hiring Pipeline Overview
                </Link>
              </li>
              <li>
                <Link href="/recruiter/jobs" className="hover:text-aqua transition-colors">
                  Post & Manage Jobs
                </Link>
              </li>
              <li>
                <Link href="/recruiter/applicants" className="hover:text-aqua transition-colors">
                  Candidate Match Analytics
                </Link>
              </li>
              <li>
                <Link href="/recruiter/company" className="hover:text-aqua transition-colors">
                  Company Profile & Branding
                </Link>
              </li>
            </ul>
          </div>

          {/* Blueprint & Architecture */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-white mb-3">
              System Blueprint
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <Link href="/blueprint" className="hover:text-violet-400 transition-colors flex items-center gap-1">
                  System Architecture <ExternalLink className="w-3 h-3" />
                </Link>
              </li>
              <li>
                <Link href="/blueprint#er-diagram" className="hover:text-violet-400 transition-colors">
                  Database ER Schema
                </Link>
              </li>
              <li>
                <Link href="/blueprint#ai-matching" className="hover:text-violet-400 transition-colors">
                  40/25/20/15 AI Scoring Logic
                </Link>
              </li>
              <li>
                <Link href="/blueprint#deployment" className="hover:text-violet-400 transition-colors">
                  Vercel + Postgres Deployment
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-10 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <p>© 2026 TalentGlass AI. Complete Full-Stack Portfolio Blueprint.</p>
          <div className="flex items-center gap-4">
            <span className="text-slate-400">Next.js 14 App Router</span>
            <span className="text-slate-600">·</span>
            <span className="text-slate-400">Prisma ORM</span>
            <span className="text-slate-600">·</span>
            <span className="text-slate-400">Tailwind Glassmorphism</span>
            <span className="text-slate-600">·</span>
            <span className="text-aqua">AI Semantic Engine</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
