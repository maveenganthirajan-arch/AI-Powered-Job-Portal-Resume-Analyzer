import React from "react";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { GlassCard } from "@/components/glass-card";
import { User, Briefcase, GraduationCap, MapPin, Mail, Phone, Globe, Github, Linkedin, Sparkles } from "lucide-react";

export const revalidate = 0;

export default async function CandidateProfilePage() {
  const user = await getCurrentUser();
  const profile = await db.candidateProfile.findUnique({
    where: { userId: user?.id || "" },
  });

  const skills = JSON.parse(profile?.skills || "[]");
  const education = JSON.parse(profile?.education || "[]");
  const workHistory = JSON.parse(profile?.workHistory || "[]");

  return (
    <div className="space-y-8 max-w-4xl">
      <div className="space-y-1">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Candidate Profile
        </h1>
        <p className="text-xs sm:text-sm text-slate-400">
          Manage your career identity, technical skills, and portfolio credentials.
        </p>
      </div>

      {/* Header Profile Card */}
      <GlassCard className="p-8 border-white/15 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
          <img
            src={user?.avatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80"}
            alt={user?.name || "Candidate"}
            className="w-20 h-20 rounded-2xl object-cover border-2 border-violet-500/50 shadow-xl"
          />
          <div className="space-y-1.5 flex-1">
            <h2 className="text-xl font-bold text-white">{user?.name || "John Doe"}</h2>
            <p className="text-xs font-medium text-aqua">
              {profile?.headline || "Senior Frontend Engineer & React Specialist"}
            </p>
            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-1">
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-aqua" />
                {profile?.location || "San Francisco, CA"}
              </span>
              <span className="flex items-center gap-1">
                <Mail className="w-3.5 h-3.5 text-violet-400" />
                {user?.email || "john@example.com"}
              </span>
              <span className="flex items-center gap-1">
                <Briefcase className="w-3.5 h-3.5 text-emerald-400" />
                {profile?.experienceYears || 5} Years Experience
              </span>
            </div>
          </div>
        </div>

        {/* Bio */}
        {profile?.bio && (
          <p className="mt-6 pt-6 border-t border-white/10 text-xs text-slate-300 leading-relaxed">
            {profile.bio}
          </p>
        )}
      </GlassCard>

      {/* Skills Showcase */}
      <GlassCard className="p-6 space-y-4 border-white/15">
        <h3 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-aqua" />
          Technical Skills & Technologies
        </h3>
        <div className="flex flex-wrap gap-2">
          {skills.map((skill: string) => (
            <span
              key={skill}
              className="px-3 py-1 rounded-xl bg-violet-600/20 border border-violet-500/30 text-xs font-medium text-slate-200"
            >
              {skill}
            </span>
          ))}
        </div>
      </GlassCard>

      {/* Work History */}
      <GlassCard className="p-6 space-y-4 border-white/15">
        <h3 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
          <Briefcase className="w-4 h-4 text-violet-400" />
          Professional Experience
        </h3>
        <div className="space-y-4">
          {workHistory.map((w: any, idx: number) => (
            <div key={idx} className="p-4 rounded-xl bg-white/5 border border-white/5 space-y-1.5">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="text-xs font-bold text-white">{w.role}</h4>
                  <p className="text-[11px] text-aqua">{w.company}</p>
                </div>
                <span className="text-[11px] text-slate-400 font-mono">{w.period}</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">{w.description}</p>
            </div>
          ))}
        </div>
      </GlassCard>

      {/* Education */}
      <GlassCard className="p-6 space-y-4 border-white/15">
        <h3 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
          <GraduationCap className="w-4 h-4 text-aqua" />
          Education
        </h3>
        <div className="space-y-3">
          {education.map((e: any, idx: number) => (
            <div key={idx} className="p-4 rounded-xl bg-white/5 border border-white/5 flex justify-between items-center text-xs">
              <div>
                <h4 className="font-bold text-white">{e.degree}</h4>
                <p className="text-slate-400 text-[11px]">{e.institution}</p>
              </div>
              <span className="font-mono text-slate-400 text-[11px]">{e.year}</span>
            </div>
          ))}
        </div>
      </GlassCard>
    </div>
  );
}
