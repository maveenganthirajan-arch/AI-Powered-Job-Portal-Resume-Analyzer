import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ savedJobs: [] });
    }

    const saved = await db.savedJob.findMany({
      where: { userId: user.id },
      include: {
        job: {
          include: { company: true },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    const parsed = saved.map((s) => ({
      id: s.id,
      jobId: s.jobId,
      createdAt: s.createdAt,
      job: {
        ...s.job,
        requirements: JSON.parse(s.job.requirements || "[]"),
        benefits: JSON.parse(s.job.benefits || "[]"),
        requiredSkills: JSON.parse(s.job.requiredSkills || "[]"),
        status: s.job.status as any,
      },
    }));

    return NextResponse.json({ savedJobs: parsed });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { jobId } = await req.json();
    if (!jobId) {
      return NextResponse.json({ error: "jobId is required" }, { status: 400 });
    }

    // Toggle saved state
    const existing = await db.savedJob.findUnique({
      where: {
        userId_jobId: {
          userId: user.id,
          jobId,
        },
      },
    });

    if (existing) {
      await db.savedJob.delete({ where: { id: existing.id } });
      return NextResponse.json({ saved: false });
    } else {
      await db.savedJob.create({
        data: {
          userId: user.id,
          jobId,
        },
      });
      return NextResponse.json({ saved: true });
    }
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}
