"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Sparkles,
  Search,
  Briefcase,
  Layers,
  Bell,
  User,
  CheckCircle,
  FileText,
  Building,
  Menu,
  X,
  ArrowRight,
  ShieldCheck,
} from "lucide-react";
import { cn } from "@/lib/utils";

export function Navbar() {
  const pathname = usePathname();
  const router = useRouter();
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [isSwitching, setIsSwitching] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    fetchSession();
  }, [pathname]);

  const fetchSession = async () => {
    try {
      const res = await fetch("/api/auth/me");
      if (res.ok) {
        const data = await res.json();
        setCurrentUser(data.user);
      }
      const notifRes = await fetch("/api/notifications");
      if (notifRes.ok) {
        const notifData = await notifRes.json();
        setNotifications(notifData.notifications || []);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const switchRole = async (targetRole: "CANDIDATE" | "RECRUITER") => {
    setIsSwitching(true);
    try {
      const res = await fetch("/api/auth/me", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role: targetRole }),
      });
      if (res.ok) {
        const data = await res.json();
        setCurrentUser(data.user);
        if (targetRole === "RECRUITER") {
          router.push("/recruiter/dashboard");
        } else {
          router.push("/candidate/dashboard");
        }
      }
    } finally {
      setIsSwitching(false);
    }
  };

  const isCandidate = currentUser?.role === "CANDIDATE";
  const isRecruiter = currentUser?.role === "RECRUITER";
  const unreadNotifs = notifications.filter((n) => !n.read).length;

  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-[#0B1020]/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Brand Logo */}
        <div className="flex items-center gap-8">
          <Link href="/" className="flex items-center gap-2.5 group">
            <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-violet-600 via-violet-500 to-aqua shadow-lg shadow-violet-500/20 group-hover:shadow-violet-500/40 transition-all">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold tracking-tight text-white flex items-center gap-1.5">
                TalentGlass <span className="text-aqua text-xs font-semibold px-1.5 py-0.5 rounded bg-aqua/10 border border-aqua/30">AI</span>
              </span>
              <span className="text-[10px] text-slate-400 font-medium">Smart Hiring & Resume Match</span>
            </div>
          </Link>

          {/* Primary Nav Links */}
          <nav className="hidden md:flex items-center gap-1">
            <Link
              href="/jobs"
              className={cn(
                "px-3 py-1.5 rounded-lg text-sm font-medium transition-colors",
                pathname.startsWith("/jobs")
                  ? "text-white bg-white/10"
                  : "text-slate-300 hover:text-white hover:bg-white/5"
              )}
            >
              Find Jobs
            </Link>

            <Link
              href="/candidate/resume"
              className={cn(
                "px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5",
                pathname === "/candidate/resume"
                  ? "text-aqua bg-aqua/10 border border-aqua/30"
                  : "text-slate-300 hover:text-white hover:bg-white/5"
              )}
            >
              <Sparkles className="w-3.5 h-3.5 text-aqua" />
              Resume Analyzer
            </Link>

            <Link
              href="/candidate/dashboard"
              className={cn(
                "px-3 py-1.5 rounded-lg text-sm font-medium transition-colors",
                pathname.startsWith("/candidate") && pathname !== "/candidate/resume"
                  ? "text-white bg-white/10"
                  : "text-slate-300 hover:text-white hover:bg-white/5"
              )}
            >
              Candidate Portal
            </Link>

            <Link
              href="/recruiter/dashboard"
              className={cn(
                "px-3 py-1.5 rounded-lg text-sm font-medium transition-colors",
                pathname.startsWith("/recruiter")
                  ? "text-white bg-white/10"
                  : "text-slate-300 hover:text-white hover:bg-white/5"
              )}
            >
              Recruiter Hub
            </Link>

            <Link
              href="/blueprint"
              className={cn(
                "px-3 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1 text-slate-400 hover:text-white",
                pathname === "/blueprint" && "text-violet-400 bg-violet-500/10 border border-violet-500/30"
              )}
            >
              <Layers className="w-3.5 h-3.5" />
              Blueprint 2026
            </Link>
          </nav>
        </div>

        {/* Right side controls: Role quick switch, notifications, profile */}
        <div className="flex items-center gap-3">
          {/* Quick Demo Switcher Pill */}
          <div className="hidden lg:flex items-center bg-white/5 border border-white/10 rounded-full p-0.5 text-xs">
            <button
              onClick={() => switchRole("CANDIDATE")}
              disabled={isSwitching}
              className={cn(
                "px-3 py-1 rounded-full font-medium transition-all flex items-center gap-1.5",
                isCandidate
                  ? "bg-gradient-to-r from-violet-600 to-violet-500 text-white shadow-sm"
                  : "text-slate-400 hover:text-white"
              )}
            >
              <User className="w-3 h-3" />
              Candidate (John)
            </button>
            <button
              onClick={() => switchRole("RECRUITER")}
              disabled={isSwitching}
              className={cn(
                "px-3 py-1 rounded-full font-medium transition-all flex items-center gap-1.5",
                isRecruiter
                  ? "bg-gradient-to-r from-aqua to-teal-400 text-midnight-950 font-semibold shadow-sm"
                  : "text-slate-400 hover:text-white"
              )}
            >
              <Building className="w-3 h-3" />
              Recruiter (Sarah)
            </button>
          </div>

          {/* Notifications Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/5 transition-colors border border-white/5"
              aria-label="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifs > 0 && (
                <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-aqua animate-pulse" />
              )}
            </button>

            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 rounded-2xl glass-panel border border-white/15 p-4 shadow-2xl z-50">
                <div className="flex items-center justify-between pb-3 border-b border-white/10">
                  <h4 className="text-xs font-semibold text-white uppercase tracking-wider">
                    Notifications
                  </h4>
                  <span className="text-[11px] text-aqua">{unreadNotifs} new</span>
                </div>
                <div className="mt-3 space-y-2.5 max-h-64 overflow-y-auto">
                  {notifications.length === 0 ? (
                    <p className="text-xs text-slate-400 py-3 text-center">No notifications yet</p>
                  ) : (
                    notifications.map((n) => (
                      <Link
                        key={n.id}
                        href={n.link || "#"}
                        onClick={() => setShowNotifications(false)}
                        className="block p-2 rounded-xl bg-white/5 hover:bg-white/10 transition-colors border border-white/5"
                      >
                        <p className="text-xs font-medium text-slate-200">{n.title}</p>
                        <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-2">{n.message}</p>
                      </Link>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* User Profile avatar */}
          {currentUser ? (
            <Link
              href={isRecruiter ? "/recruiter/dashboard" : "/candidate/dashboard"}
              className="flex items-center gap-2 pl-2 border-l border-white/10"
            >
              <img
                src={currentUser.avatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80"}
                alt={currentUser.name}
                className="w-8 h-8 rounded-full border border-violet-500/50 object-cover"
              />
              <div className="hidden sm:flex flex-col text-left">
                <span className="text-xs font-semibold text-white leading-tight">
                  {currentUser.name}
                </span>
                <span className="text-[10px] text-slate-400">
                  {isRecruiter ? "Recruiter" : "Candidate"}
                </span>
              </div>
            </Link>
          ) : (
            <div className="flex items-center gap-2">
              <Link
                href="/login"
                className="px-3.5 py-1.5 text-xs font-medium text-white hover:bg-white/5 rounded-lg transition-colors"
              >
                Sign In
              </Link>
              <Link
                href="/register"
                className="px-3.5 py-1.5 text-xs font-medium text-midnight-950 bg-aqua hover:bg-aqua-bright rounded-lg font-semibold transition-all shadow-sm"
              >
                Sign Up
              </Link>
            </div>
          )}

          {/* Mobile hamburger menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/5"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile nav drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-white/10 bg-[#0B1020]/95 px-4 pt-3 pb-6 space-y-3">
          <Link
            href="/jobs"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 rounded-lg text-sm text-slate-200 hover:bg-white/5"
          >
            Find Jobs
          </Link>
          <Link
            href="/candidate/resume"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 rounded-lg text-sm text-aqua font-medium hover:bg-white/5"
          >
            ✨ Resume Analyzer
          </Link>
          <Link
            href="/candidate/dashboard"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 rounded-lg text-sm text-slate-200 hover:bg-white/5"
          >
            Candidate Portal
          </Link>
          <Link
            href="/recruiter/dashboard"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 rounded-lg text-sm text-slate-200 hover:bg-white/5"
          >
            Recruiter Hub
          </Link>
          <Link
            href="/blueprint"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3 py-2 rounded-lg text-sm text-violet-400 hover:bg-white/5"
          >
            Blueprint 2026
          </Link>
          <div className="pt-3 border-t border-white/10 flex gap-2">
            <button
              onClick={() => {
                switchRole("CANDIDATE");
                setMobileMenuOpen(false);
              }}
              className="flex-1 py-1.5 text-xs text-center rounded-lg bg-violet-600 text-white font-medium"
            >
              Role: Candidate
            </button>
            <button
              onClick={() => {
                switchRole("RECRUITER");
                setMobileMenuOpen(false);
              }}
              className="flex-1 py-1.5 text-xs text-center rounded-lg bg-aqua text-midnight-950 font-bold"
            >
              Role: Recruiter
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
