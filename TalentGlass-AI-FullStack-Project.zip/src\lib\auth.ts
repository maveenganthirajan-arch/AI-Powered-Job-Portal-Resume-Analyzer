import { cookies } from "next/headers";
import { db } from "./db";
import { UserSession } from "@/types";

const AUTH_COOKIE = "talentglass_session_user";

export async function getCurrentUser(): Promise<UserSession | null> {
  try {
    const cookieStore = cookies();
    const sessionCookie = cookieStore.get(AUTH_COOKIE)?.value;

    if (sessionCookie) {
      try {
        const parsed = JSON.parse(decodeURIComponent(sessionCookie));
        if (parsed?.id) {
          // Verify user still exists in DB
          const user = await db.user.findUnique({
            where: { id: parsed.id },
            select: { id: true, email: true, name: true, role: true, avatar: true },
          });
          if (user) return user as UserSession;
        }
      } catch (e) {
        // Fallback to default candidate if malformed
      }
    }

    // Default to candidate John Doe for seamless test drive
    const defaultUser = await db.user.findFirst({
      where: { role: "CANDIDATE" },
      select: { id: true, email: true, name: true, role: true, avatar: true },
    });

    return (defaultUser as UserSession) || null;
  } catch (err) {
    return null;
  }
}

export function createSessionCookie(user: UserSession): { name: string; value: string; options: any } {
  return {
    name: AUTH_COOKIE,
    value: encodeURIComponent(JSON.stringify(user)),
    options: {
      httpOnly: false, // accessible for client-side quick switch
      path: "/",
      maxAge: 60 * 60 * 24 * 7, // 7 days
      sameSite: "lax",
    },
  };
}
