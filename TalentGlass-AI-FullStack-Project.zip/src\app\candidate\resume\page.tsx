"use client";

import React, { useState, useEffect } from "react";
import { GlassCard } from "@/components/glass-card";
import { FileUpload } from "@/components/file-upload";
import { ScoreCard } from "@/components/score-card";
import { AIAnalysisResult, JobData, ResumeData } from "@/types";
import {
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  FileText,
  Briefcase,
  Loader2,
  ArrowRight,
  Info,
  ShieldAlert,
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function ResumeAnalyzerPage() {
  const [resumes, setResumes] = useState<ResumeData[]>([]);
  const [jobs, setJobs] = useState<JobData[]>([]);
  const [selectedResumeId, setSelectedResumeId] = useState<string>("");
  const [selectedJobId, setSelectedJobId] = useState<string>("");
  const [customRoleText, setCustomRoleText] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AIAnalysisResult | null>(null);

  useEffect(() => {
    fetchInitialData();
  }, []);

  const fetchInitialData = async () => {
    try {
      const [resumesRes, jobsRes] = await Promise.all([
        fetch("/api/resumes"),
        fetch("/api/jobs"),
      ]);

      if (resumesRes.ok) {
        const rData = await resumesRes.json();
        setResumes(rData.resumes || []);
        if (rData.resumes?.length > 0) {
          setSelectedResumeId(rData.resumes[0].id);
          // Check if latest resume has analysis
          if (rData.resumes[0].analyses?.length > 0) {
            setAnalysisResult(rData.resumes[0].analyses[0]);
          }
        }
      }

      if (jobsRes.ok) {
        const jData = await jobsRes.json();
        setJobs(jData.jobs || []);
        if (jData.jobs?.length > 0) {
          setSelectedJobId(jData.jobs[0].id);
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleUploadSuccess = (newResume: any) => {
    setResumes((prev) => [newResume, ...prev]);
    setSelectedResumeId(newResume.id);
    // Automatically trigger analysis
    runAnalysis(newResume.id, selectedJobId);
  };

  const runAnalysis = async (resumeIdToUse?: string, jobIdToUse?: string) => {
    const resumeId = resumeIdToUse || selectedResumeId;
    const jobId = jobIdToUse || selectedJobId;

    setIsAnalyzing(true);
    try {
      const res = await fetch("/api/ai/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          resumeId: resumeId || undefined,
          jobId: jobId || undefined,
          customJobDescription: customRoleText || undefined,
        }),
      });

      const data = await res.json();
      if (res.ok && data.result) {
        setAnalysisResult(data.result);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Page Header (Panel 5) */}
      <div className="space-y-1">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-aqua/10 border border-aqua/30 text-xs font-semibold text-aqua mb-2">
          <Sparkles className="w-3.5 h-3.5" />
          ATS Semantic Engine · 2026
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Resume Analyzer
        </h1>
        <p className="text-xs sm:text-sm text-slate-400">
          Upload your resume and get instant, structured AI-powered feedback against real job roles.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: File Upload & Target Selection (Panel 5) */}
        <div className="lg:col-span-5 space-y-6">
          <GlassCard className="p-6 space-y-6 border-white/15">
            <h3 className="text-sm font-bold uppercase tracking-wider text-white pb-3 border-b border-white/10">
              Upload & Configure
            </h3>

            {/* Drag & drop file upload */}
            <FileUpload onUploadSuccess={handleUploadSuccess} />

            {/* Existing Resumes Selector */}
            {resumes.length > 0 && (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">
                  Or select uploaded resume:
                </label>
                <select
                  value={selectedResumeId}
                  onChange={(e) => setSelectedResumeId(e.target.value)}
                  className="w-full rounded-xl bg-white/5 border border-white/10 p-2.5 text-xs text-white focus:outline-none focus:border-violet-500"
                >
                  {resumes.map((r) => (
                    <option key={r.id} value={r.id} className="bg-midnight-900 text-white">
                      {r.fileName}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Target Job Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2">
                Target Role for Match Comparison:
              </label>
              <select
                value={selectedJobId}
                onChange={(e) => setSelectedJobId(e.target.value)}
                className="w-full rounded-xl bg-white/5 border border-white/10 p-2.5 text-xs text-white focus:outline-none focus:border-violet-500"
              >
                {jobs.map((j) => (
                  <option key={j.id} value={j.id} className="bg-midnight-900 text-white">
                    {j.title} · {j.company?.name || "Company"} ({j.salaryRange})
                  </option>
                ))}
              </select>
            </div>

            {/* Scan button */}
            <button
              onClick={() => runAnalysis()}
              disabled={isAnalyzing}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-violet-600 via-violet-500 to-aqua text-white text-xs font-bold shadow-lg shadow-violet-500/25 hover:opacity-95 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Running Semantic Evaluation...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Scan Resume with AI
                </>
              )}
            </button>

            {/* ATS Disclaimer note */}
            <div className="p-3 rounded-xl bg-white/5 border border-white/5 text-[11px] text-slate-400 flex items-start gap-2">
              <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
              <span>
                Scores are estimates calculated via a transparent 40/25/20/15 weighted rubric. They do not infer protected characteristics.
              </span>
            </div>
          </GlassCard>
        </div>

        {/* Right Column: Analysis Results (Panel 5) */}
        <div className="lg:col-span-7 space-y-6">
          <GlassCard className="p-6 sm:p-8 space-y-6 border-white/15">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-aqua" />
                Analysis Results
              </h3>
              <span className="text-xs text-slate-400">
                {isAnalyzing ? "Processing..." : "Latest Evaluation"}
              </span>
            </div>

            {isAnalyzing ? (
              <div className="py-20 text-center space-y-4">
                <div className="inline-block w-12 h-12 border-4 border-aqua border-t-transparent rounded-full animate-spin" />
                <h4 className="text-sm font-semibold text-white">Scanning Resume Text...</h4>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  Parsing technical skills, experience tenure, and project relevance against job criteria.
                </p>
              </div>
            ) : analysisResult ? (
              <div className="space-y-6">
                {/* Overall Score Radial Gauge */}
                <div className="flex flex-col sm:flex-row items-center justify-center gap-8 py-4 bg-white/[0.02] rounded-2xl border border-white/5 p-6">
                  <ScoreCard
                    score={analysisResult.overallScore}
                    label={analysisResult.overallScore >= 70 ? "Good Match" : "Moderate Match"}
                    size="lg"
                  />
                  <div className="flex-1 w-full space-y-3">
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-400">Required Skills (40%)</span>
                        <span className="font-semibold text-white">{analysisResult.skillsMatchScore}%</span>
                      </div>
                      <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                        <div className="h-full bg-aqua" style={{ width: `${analysisResult.skillsMatchScore}%` }} />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-400">Experience Tenure (25%)</span>
                        <span className="font-semibold text-white">{analysisResult.experienceScore}%</span>
                      </div>
                      <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                        <div className="h-full bg-violet-400" style={{ width: `${analysisResult.experienceScore}%` }} />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-400">Project Relevance (20%)</span>
                        <span className="font-semibold text-white">{analysisResult.projectsScore}%</span>
                      </div>
                      <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                        <div className="h-full bg-purple-400" style={{ width: `${analysisResult.projectsScore}%` }} />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-400">Education & Certs (15%)</span>
                        <span className="font-semibold text-white">{analysisResult.educationScore}%</span>
                      </div>
                      <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                        <div className="h-full bg-teal-300" style={{ width: `${analysisResult.educationScore}%` }} />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Strengths (Matching Panel 5 green bullets) */}
                <div className="space-y-2.5">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Strengths
                  </h4>
                  <ul className="space-y-2">
                    {analysisResult.strengths.map((str, idx) => (
                      <li
                        key={idx}
                        className="flex items-start gap-2.5 text-xs text-slate-200 p-2.5 rounded-xl bg-emerald-500/5 border border-emerald-500/15"
                      >
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{str}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Missing Skills (Matching Panel 5 amber bullets) */}
                <div className="space-y-2.5">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    Missing Skills
                  </h4>
                  <ul className="space-y-2">
                    {analysisResult.missingSkills.map((sk, idx) => (
                      <li
                        key={idx}
                        className="flex items-start gap-2.5 text-xs text-slate-200 p-2.5 rounded-xl bg-amber-500/5 border border-amber-500/15"
                      >
                        <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        <span>{sk}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Suggestions (Matching Panel 5 blue bullets) */}
                <div className="space-y-2.5">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-aqua flex items-center gap-1.5">
                    <Lightbulb className="w-3.5 h-3.5" />
                    Suggestions
                  </h4>
                  <ul className="space-y-2">
                    {analysisResult.suggestions.map((sug, idx) => (
                      <li
                        key={idx}
                        className="flex items-start gap-2.5 text-xs text-slate-200 p-2.5 rounded-xl bg-aqua/5 border border-aqua/15"
                      >
                        <Lightbulb className="w-4 h-4 text-aqua shrink-0 mt-0.5" />
                        <span>{sug}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Job Match Explanation Paragraph */}
                {analysisResult.jobMatchExplanation && (
                  <div className="p-4 rounded-xl bg-violet-600/10 border border-violet-500/20 text-xs text-slate-300">
                    <span className="font-semibold text-white block mb-1">
                      AI Match Assessment:
                    </span>
                    <p className="leading-relaxed">{analysisResult.jobMatchExplanation}</p>
                  </div>
                )}
              </div>
            ) : (
              <div className="py-16 text-center space-y-3">
                <FileText className="w-10 h-10 text-slate-500 mx-auto" />
                <h4 className="text-sm font-semibold text-white">No Analysis Ready</h4>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  Upload a resume file on the left and click "Scan Resume with AI" to generate real-time feedback.
                </p>
              </div>
            )}
          </GlassCard>
        </div>
      </div>
    </div>
  );
}
