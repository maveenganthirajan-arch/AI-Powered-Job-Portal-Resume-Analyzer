import React from "react";
import { cn } from "@/lib/utils";

interface GlassCardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  interactive?: boolean;
  glow?: "violet" | "aqua" | "none";
  className?: string;
}

export function GlassCard({
  children,
  interactive = false,
  glow = "none",
  className,
  ...props
}: GlassCardProps) {
  return (
    <div
      className={cn(
        interactive ? "glass-card-interactive cursor-pointer" : "glass-card",
        "relative overflow-hidden p-6",
        glow === "violet" && "border-violet-500/30 shadow-[0_0_30px_rgba(124,92,252,0.15)]",
        glow === "aqua" && "border-aqua/30 shadow-[0_0_30px_rgba(53,214,197,0.15)]",
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}
