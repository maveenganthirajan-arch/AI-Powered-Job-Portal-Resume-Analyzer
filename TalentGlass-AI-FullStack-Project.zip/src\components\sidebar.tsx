"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Briefcase,
  FileText,
  Bookmark,
  User,
  Users,
  Settings,
  Sparkles,
  Building2,
  Send,
  Layers,
  ChevronRight,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SidebarProps {
  role?: "CANDIDATE" | "RECRUITER";
  user?: {
    name?: string;
    role?: string;
    avatar?: string | null;
    email?: string;
  };
}

export function Sidebar({ role = "CANDIDATE", user }: SidebarProps) {
  const pathname = usePathname();

  const candidateLinks = [
    { name: "Dashboard", href: "/candidate/dashboard", icon: LayoutDashboard },
    { name: "Find Jobs", href: "/jobs", icon: Briefcase },
    { name: "Applications", href: "/candidate/applications", icon: Send },
    { name: "Resume Analyzer", href: "/candidate/resume", icon: Sparkles, badge: "AI" },
    { name: "Saved Jobs", href: "/candidate/saved-jobs", icon: Bookmark },
    { name: "Profile", href: "/candidate/profile", icon: User },
  ];

  const recruiterLinks = [
    { name: "Dashboard", href: "/recruiter/dashboard", icon: LayoutDashboard },
    { name: "Job Postings", href: "/recruiter/jobs", icon: Briefcase },
    { name: "Applicants", href: "/recruiter/applicants", icon: Users, badge: "128" },
    { name: "Company Profile", href: "/recruiter/company", icon: Building2 },
    { name: "Architecture", href: "/blueprint", icon: Layers },
  ];

  const links = role === "RECRUITER" ? recruiterLinks : candidateLinks;

  return (
    <aside className="w-64 shrink-0 hidden md:flex flex-col justify-between p-4 glass-card border-white/10 my-4 ml-4 h-[calc(100vh-6rem)] sticky top-20">
      {/* Top Links */}
      <div className="space-y-6">
        {/* Brand identity badge */}
        <div className="flex items-center gap-3 px-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-violet-600 to-aqua shadow-md">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white leading-tight">TalentGlass AI</h2>
            <p className="text-[10px] text-slate-400 capitalize">
              {role === "RECRUITER" ? "Recruiter Portal" : "Candidate Portal"}
            </p>
          </div>
        </div>

        {/* Navigation list */}
        <nav className="space-y-1">
          {links.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  "flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium transition-all group",
                  isActive
                    ? "bg-violet-600/20 text-white border border-violet-500/40 shadow-sm"
                    : "text-slate-400 hover:text-white hover:bg-white/5"
                )}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={cn(
                      "w-4 h-4 transition-colors",
                      isActive ? "text-aqua" : "text-slate-400 group-hover:text-white"
                    )}
                  />
                  <span>{item.name}</span>
                </div>
                {item.badge && (
                  <span
                    className={cn(
                      "text-[9px] px-1.5 py-0.5 rounded font-bold uppercase",
                      item.badge === "AI"
                        ? "bg-aqua/20 text-aqua border border-aqua/30"
                        : "bg-violet-500/20 text-violet-300 border border-violet-500/30"
                    )}
                  >
                    {item.badge}
                  </span>
                )}
              </Link>
            );
          })}
        </nav>
      </div>

      {/* User profile footer info */}
      <div className="pt-4 border-t border-white/10">
        <div className="flex items-center gap-3 p-2 rounded-xl bg-white/5 border border-white/5">
          <img
            src={
              user?.avatar ||
              (role === "RECRUITER"
                ? "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=250&q=80"
                : "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80")
            }
            alt="Profile avatar"
            className="w-9 h-9 rounded-full object-cover border border-white/20"
          />
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium text-white truncate">
              {user?.name || (role === "RECRUITER" ? "Sarah Wilson" : "John Doe")}
            </p>
            <p className="text-[10px] text-slate-400 capitalize">
              {role === "RECRUITER" ? "Recruiter" : "Candidate"}
            </p>
          </div>
        </div>
      </div>
    </aside>
  );
}
