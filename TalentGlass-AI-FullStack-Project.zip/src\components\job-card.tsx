"use client";

import React, { useState } from "react";
import Link from "next/link";
import { JobData } from "@/types";
import { GlassCard } from "./glass-card";
import {
  Briefcase,
  MapPin,
  DollarSign,
  Bookmark,
  Sparkles,
  ArrowRight,
  CheckCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface JobCardProps {
  job: JobData;
  isSavedInitial?: boolean;
  onApplyClick?: (job: JobData) => void;
  matchScore?: number;
}

export function JobCard({
  job,
  isSavedInitial = false,
  onApplyClick,
  matchScore,
}: JobCardProps) {
  const [isSaved, setIsSaved] = useState(isSavedInitial);
  const [isSaving, setIsSaving] = useState(false);

  const toggleSave = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsSaving(true);
    try {
      const res = await fetch("/api/saved-jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jobId: job.id }),
      });
      if (res.ok) {
        const data = await res.json();
        setIsSaved(data.saved);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsSaving(false);
    }
  };

  // Generate plausible match score if not provided
  const displayScore = matchScore ?? (job.title.includes("Frontend") ? 78 : job.title.includes("Full Stack") ? 82 : 71);

  return (
    <GlassCard interactive className="p-5 flex flex-col justify-between group">
      <div>
        {/* Header row: Company logo, name, location, save button */}
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center overflow-hidden shrink-0">
              {job.company?.logo ? (
                <img
                  src={job.company.logo}
                  alt={job.company.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <Briefcase className="w-6 h-6 text-violet-400" />
              )}
            </div>
            <div>
              <h3 className="text-base font-semibold text-white group-hover:text-aqua transition-colors line-clamp-1">
                <Link href={`/jobs/${job.id}`}>{job.title}</Link>
              </h3>
              <p className="text-xs text-slate-400 font-medium">
                {job.company?.name || "TechCorp"}
              </p>
            </div>
          </div>

          <button
            onClick={toggleSave}
            disabled={isSaving}
            className={cn(
              "p-2 rounded-xl border transition-all",
              isSaved
                ? "bg-violet-600/20 border-violet-500/50 text-violet-400"
                : "bg-white/5 border-white/10 text-slate-400 hover:text-white hover:border-white/20"
            )}
            title={isSaved ? "Saved to Bookmarks" : "Save Job"}
          >
            <Bookmark className={cn("w-4 h-4", isSaved && "fill-violet-400")} />
          </button>
        </div>

        {/* Badges: Type, Location, Salary */}
        <div className="flex flex-wrap items-center gap-2 mt-4 text-xs text-slate-300">
          <span className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-aqua" />
            {job.location}
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10">
            {job.type}
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-medium flex items-center gap-1">
            <DollarSign className="w-3 h-3" />
            {job.salaryRange}
          </span>
        </div>

        {/* Skills Chips */}
        <div className="flex flex-wrap gap-1.5 mt-3.5">
          {job.requiredSkills.slice(0, 4).map((skill) => (
            <span
              key={skill}
              className="text-[11px] px-2 py-0.5 rounded-md bg-white/5 border border-white/5 text-slate-300 font-medium"
            >
              {skill}
            </span>
          ))}
          {job.requiredSkills.length > 4 && (
            <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-white/5 text-slate-400">
              +{job.requiredSkills.length - 4}
            </span>
          )}
        </div>
      </div>

      {/* Footer row: AI Match Badge & Actions */}
      <div className="flex items-center justify-between pt-4 mt-4 border-t border-white/10">
        <div className="flex items-center gap-1.5">
          <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-gradient-to-r from-violet-600/20 to-aqua/20 border border-aqua/30 text-xs font-semibold text-aqua">
            <Sparkles className="w-3.5 h-3.5" />
            {displayScore}% Match
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onApplyClick ? (
            <button
              onClick={() => onApplyClick(job)}
              className="px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-violet-600 hover:bg-violet-500 text-white transition-all shadow-md hover:shadow-violet-500/25 flex items-center gap-1"
            >
              Apply
              <ArrowRight className="w-3 h-3" />
            </button>
          ) : (
            <Link
              href={`/jobs/${job.id}`}
              className="px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-violet-600 hover:bg-violet-500 text-white transition-all shadow-md hover:shadow-violet-500/25 flex items-center gap-1"
            >
              View Role
              <ArrowRight className="w-3 h-3" />
            </Link>
          )}
        </div>
      </div>
    </GlassCard>
  );
}
