"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { GlassCard } from "@/components/glass-card";
import { JobData } from "@/types";
import {
  Briefcase,
  Plus,
  MapPin,
  DollarSign,
  Users,
  CheckCircle2,
  X,
  Loader2,
  AlertCircle,
  ExternalLink,
} from "lucide-react";

export default function RecruiterJobsPage() {
  const [jobs, setJobs] = useState<JobData[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // New Job Form State
  const [title, setTitle] = useState("");
  const [department, setDepartment] = useState("Engineering");
  const [type, setType] = useState("Remote · Full-time");
  const [location, setLocation] = useState("Remote / San Francisco, CA");
  const [salaryRange, setSalaryRange] = useState("$120k - $160k");
  const [description, setDescription] = useState("");
  const [requirementsInput, setRequirementsInput] = useState("3+ years React and TypeScript\nExperience with Next.js SSR\nProficiency in modern CSS and responsive design");
  const [skillsInput, setSkillsInput] = useState("React, TypeScript, Next.js, Tailwind CSS");

  useEffect(() => {
    fetchJobs();
  }, []);

  const fetchJobs = async () => {
    try {
      const res = await fetch("/api/jobs");
      if (res.ok) {
        const data = await res.json();
        setJobs(data.jobs || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateJob = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);

    try {
      const requirements = requirementsInput
        .split("\n")
        .map((s) => s.trim())
        .filter(Boolean);
      const requiredSkills = skillsInput
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean);

      const res = await fetch("/api/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          department,
          type,
          location,
          salaryRange,
          description: description || `We are looking for an experienced ${title} to join our growing team.`,
          requirements,
          requiredSkills,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to publish job");
      }

      setIsModalOpen(false);
      fetchJobs();
    } catch (err: any) {
      setError(err.message || "Failed to create job");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Job Postings
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            Publish openings, manage requirements, and review candidate applicant pipelines.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-aqua text-white text-xs font-bold shadow-lg shadow-violet-500/20 hover:opacity-95 transition-all flex items-center gap-1.5 w-fit"
        >
          <Plus className="w-4 h-4" />
          Create New Job
        </button>
      </div>

      {/* Jobs Table */}
      <GlassCard className="p-0 overflow-hidden border-white/15">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-white/10 bg-white/[0.02] text-slate-400">
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px]">
                  Job Title
                </th>
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px]">
                  Department & Type
                </th>
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px]">
                  Salary Range
                </th>
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px]">
                  Status
                </th>
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px] text-right">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {jobs.map((job) => (
                <tr key={job.id} className="hover:bg-white/[0.03] transition-colors">
                  <td className="py-4 px-6">
                    <span className="font-semibold text-white block">{job.title}</span>
                    <span className="text-[11px] text-slate-400">{job.location}</span>
                  </td>
                  <td className="py-4 px-6 text-slate-300">
                    <div>{job.department || "General"}</div>
                    <div className="text-[11px] text-slate-400">{job.type}</div>
                  </td>
                  <td className="py-4 px-6 text-emerald-400 font-semibold">{job.salaryRange}</td>
                  <td className="py-4 px-6">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      ACTIVE
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right">
                    <Link
                      href={`/jobs/${job.id}`}
                      className="px-3 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 text-[11px] font-semibold transition-colors inline-flex items-center gap-1"
                    >
                      View <ExternalLink className="w-3 h-3" />
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>

      {/* Create Job Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-midnight-950/80 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-2xl glass-panel border border-white/20 p-6 md:p-8 rounded-3xl shadow-2xl overflow-y-auto max-h-[90vh]">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-aqua" />
                Publish New Job Posting
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {error && (
              <div className="mt-4 flex items-center gap-2 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleCreateJob} className="mt-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Job Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Senior Frontend Engineer"
                    className="w-full rounded-xl bg-white/5 border border-white/10 p-2.5 text-xs text-white focus:outline-none focus:border-violet-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Department
                  </label>
                  <input
                    type="text"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    placeholder="e.g. Cloud Infrastructure"
                    className="w-full rounded-xl bg-white/5 border border-white/10 p-2.5 text-xs text-white focus:outline-none focus:border-violet-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Job Type
                  </label>
                  <input
                    type="text"
                    value={type}
                    onChange={(e) => setType(e.target.value)}
                    placeholder="Remote · Full-time"
                    className="w-full rounded-xl bg-white/5 border border-white/10 p-2.5 text-xs text-white focus:outline-none focus:border-violet-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Location *
                  </label>
                  <input
                    type="text"
                    required
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="Remote / San Francisco"
                    className="w-full rounded-xl bg-white/5 border border-white/10 p-2.5 text-xs text-white focus:outline-none focus:border-violet-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Salary Range *
                  </label>
                  <input
                    type="text"
                    required
                    value={salaryRange}
                    onChange={(e) => setSalaryRange(e.target.value)}
                    placeholder="$120k - $160k"
                    className="w-full rounded-xl bg-white/5 border border-white/10 p-2.5 text-xs text-white focus:outline-none focus:border-violet-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Job Description *
                </label>
                <textarea
                  rows={3}
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe the team, mission, and day-to-day responsibilities..."
                  className="w-full rounded-xl bg-white/5 border border-white/10 p-2.5 text-xs text-white focus:outline-none focus:border-violet-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Requirements (One per line) *
                </label>
                <textarea
                  rows={3}
                  required
                  value={requirementsInput}
                  onChange={(e) => setRequirementsInput(e.target.value)}
                  className="w-full rounded-xl bg-white/5 border border-white/10 p-2.5 text-xs text-white focus:outline-none focus:border-violet-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Required Skills (Comma separated) *
                </label>
                <input
                  type="text"
                  required
                  value={skillsInput}
                  onChange={(e) => setSkillsInput(e.target.value)}
                  placeholder="React, TypeScript, Next.js, Tailwind CSS"
                  className="w-full rounded-xl bg-white/5 border border-white/10 p-2.5 text-xs text-white focus:outline-none focus:border-violet-500"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-aqua text-white text-xs font-bold shadow-lg shadow-violet-500/20 hover:opacity-95 disabled:opacity-50 flex items-center gap-2"
                >
                  {submitting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : "Publish Job Posting"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
