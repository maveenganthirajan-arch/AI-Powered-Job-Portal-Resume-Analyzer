import React from "react";
import { getJobs } from "@/services/jobs";
import { JobCard } from "@/components/job-card";
import { GlassCard } from "@/components/glass-card";
import {
  Search,
  MapPin,
  Briefcase,
  Filter,
  Sparkles,
  SlidersHorizontal,
} from "lucide-react";
import Link from "next/link";

export const revalidate = 0;

interface JobsPageProps {
  searchParams: {
    query?: string;
    location?: string;
    type?: string;
    experienceLevel?: string;
  };
}

export default async function JobsPage({ searchParams }: JobsPageProps) {
  const result = await getJobs({
    query: searchParams.query,
    location: searchParams.location,
    type: searchParams.type,
    experienceLevel: searchParams.experienceLevel,
    limit: 20,
  });

  const jobTypes = ["All", "Full-time", "Remote", "Hybrid", "Contract"];
  const expLevels = ["All", "Entry", "Mid-Level", "Senior", "Lead"];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Search Header Banner (Panel 2) */}
      <div className="relative p-8 md:p-12 rounded-3xl glass-card overflow-hidden border border-white/20 text-center">
        {/* Glow orb */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-r from-violet-600/30 to-aqua/20 blur-3xl rounded-full pointer-events-none -z-10" />

        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Find Your Dream Job
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-lg mx-auto">
          Get matched with opportunities that fit your exact skills and goals.
        </p>

        {/* Filter / Search input bar */}
        <form
          action="/jobs"
          method="GET"
          className="mt-8 max-w-3xl mx-auto p-2 glass-panel border border-white/20 shadow-2xl flex flex-col md:flex-row items-center gap-2"
        >
          <div className="flex-1 w-full flex items-center gap-2.5 px-3.5 py-2 bg-white/5 rounded-xl border border-white/10">
            <Search className="w-4 h-4 text-slate-400 shrink-0" />
            <input
              type="text"
              name="query"
              defaultValue={searchParams.query || ""}
              placeholder="Job title, skills, or keywords..."
              className="w-full bg-transparent text-xs text-white placeholder-slate-400 focus:outline-none"
            />
          </div>

          <div className="w-full md:w-56 flex items-center gap-2.5 px-3.5 py-2 bg-white/5 rounded-xl border border-white/10">
            <MapPin className="w-4 h-4 text-aqua shrink-0" />
            <input
              type="text"
              name="location"
              defaultValue={searchParams.location || ""}
              placeholder="Location..."
              className="w-full bg-transparent text-xs text-white placeholder-slate-400 focus:outline-none"
            />
          </div>

          <button
            type="submit"
            className="w-full md:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-aqua text-white text-xs font-bold shadow-lg shadow-violet-500/25 hover:opacity-95 transition-all shrink-0 flex items-center justify-center gap-2"
          >
            <Search className="w-3.5 h-3.5" />
            Search
          </button>
        </form>
      </div>

      {/* Filter Chips Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-400 font-medium flex items-center gap-1.5 mr-1">
            <Filter className="w-3 h-3 text-aqua" /> Filter:
          </span>
          {jobTypes.map((t) => {
            const isSelected =
              (!searchParams.type && t === "All") || searchParams.type === t;
            return (
              <Link
                key={t}
                href={`/jobs?${new URLSearchParams({
                  ...(searchParams.query && { query: searchParams.query }),
                  ...(searchParams.location && { location: searchParams.location }),
                  ...(t !== "All" && { type: t }),
                }).toString()}`}
                className={`px-3 py-1 rounded-xl text-xs font-medium transition-all ${
                  isSelected
                    ? "bg-violet-600 text-white shadow-sm border border-violet-400/40"
                    : "bg-white/5 text-slate-400 hover:text-white border border-white/10 hover:bg-white/10"
                }`}
              >
                {t}
              </Link>
            );
          })}
        </div>

        <div className="text-xs text-slate-400">
          Showing <span className="font-semibold text-white">{result.jobs.length}</span> positions
        </div>
      </div>

      {/* Job Cards Grid */}
      {result.jobs.length === 0 ? (
        <GlassCard className="p-12 text-center space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mx-auto text-slate-400">
            <Briefcase className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-white">No jobs match your search criteria</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Try adjusting your search terms or clearing your location filter to view all open opportunities.
          </p>
          <Link
            href="/jobs"
            className="inline-block px-4 py-2 rounded-xl bg-violet-600 text-white text-xs font-semibold"
          >
            Clear Filters
          </Link>
        </GlassCard>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {result.jobs.map((job) => (
            <JobCard key={job.id} job={job} />
          ))}
        </div>
      )}
    </div>
  );
}
