import React from "react";
import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { GlassCard } from "@/components/glass-card";
import { ScoreCard } from "@/components/score-card";
import {
  Send,
  Calendar,
  Gift,
  ArrowRight,
  Sparkles,
  Briefcase,
  MapPin,
  TrendingUp,
} from "lucide-react";

export const revalidate = 0;

export default async function CandidateDashboardPage() {
  const user = await getCurrentUser();

  // Load recommended jobs
  const jobs = await db.job.findMany({
    where: { status: "ACTIVE" },
    include: { company: true },
    take: 3,
    orderBy: { createdAt: "desc" },
  });

  const parsedJobs = jobs.map((j) => ({
    ...j,
    requiredSkills: JSON.parse(j.requiredSkills || "[]"),
  }));

  // Fetch candidate's latest analysis
  const resume = await db.resume.findFirst({
    where: { userId: user?.id || "" },
    include: {
      analyses: {
        orderBy: { createdAt: "desc" },
        take: 1,
      },
    },
  });

  const latestScore = resume?.analyses?.[0]?.overallScore || 78;

  return (
    <div className="space-y-8">
      {/* Welcome header (Panel 1) */}
      <div className="space-y-1">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Welcome back, {user?.name?.split(" ")[0] || "John"}!
        </h1>
        <p className="text-xs sm:text-sm text-slate-400">
          Explore new opportunities and grow your career with AI-guided matching.
        </p>
      </div>

      {/* Top Stat Cards (Applied Jobs: 12, Interviews: 3, Offers: 0) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Applied Jobs */}
        <GlassCard className="p-5 relative overflow-hidden border-white/10">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Applied Jobs</span>
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
              <Send className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white">12</span>
            <span className="text-[11px] font-medium text-emerald-400">+2 this week</span>
          </div>
        </GlassCard>

        {/* Interviews */}
        <GlassCard className="p-5 relative overflow-hidden border-white/10">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Interviews</span>
            <div className="w-8 h-8 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white">3</span>
            <span className="text-[11px] font-medium text-purple-300">+1 this week</span>
          </div>
        </GlassCard>

        {/* Offers */}
        <GlassCard className="p-5 relative overflow-hidden border-white/10">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Offers</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Gift className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white">0</span>
            <span className="text-[11px] font-medium text-slate-400">In pipeline</span>
          </div>
        </GlassCard>
      </div>

      {/* Main Grid: Left Recommended Jobs, Right Resume Score Gauge (Panel 1) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Recommended Jobs */}
        <div className="lg:col-span-8 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-aqua" />
              Recommended Jobs
            </h3>
            <Link
              href="/jobs"
              className="text-xs font-semibold text-aqua hover:underline flex items-center gap-1"
            >
              View all <ArrowRight className="w-3 h-3" />
            </Link>
          </div>

          <div className="space-y-3">
            {parsedJobs.map((job) => (
              <GlassCard
                key={job.id}
                interactive
                className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-white/10 hover:border-violet-500/40"
              >
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center overflow-hidden shrink-0">
                    {job.company?.logo ? (
                      <img
                        src={job.company.logo}
                        alt={job.company.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Briefcase className="w-5 h-5 text-violet-400" />
                    )}
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-white">
                      <Link href={`/jobs/${job.id}`}>{job.title}</Link>
                    </h4>
                    <p className="text-xs text-slate-400">
                      {job.company?.name} • {job.location}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4 w-full sm:w-auto justify-between sm:justify-end">
                  <span className="text-xs font-semibold text-emerald-400">
                    {job.salaryRange}
                  </span>
                  <Link
                    href={`/jobs/${job.id}`}
                    className="px-4 py-1.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold shadow-sm transition-all"
                  >
                    Apply
                  </Link>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>

        {/* Right: Your Resume Score (Panel 1) */}
        <div className="lg:col-span-4">
          <GlassCard className="p-6 flex flex-col items-center justify-between text-center border-white/15 h-full">
            <div className="w-full">
              <h3 className="text-sm font-bold uppercase tracking-wider text-white pb-3 border-b border-white/10">
                Your Resume Score
              </h3>

              <div className="py-6">
                <ScoreCard
                  score={latestScore}
                  label="Good Match"
                  size="lg"
                  showBreakdown={false}
                />
              </div>

              <p className="text-xs text-slate-300 max-w-xs mx-auto">
                Your profile is in the top 22% of applicants for Senior Frontend and Full-Stack openings.
              </p>
            </div>

            <div className="w-full pt-6">
              <Link
                href="/candidate/resume"
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-aqua text-white text-xs font-bold shadow-lg shadow-violet-500/20 hover:opacity-95 transition-all flex items-center justify-center gap-2"
              >
                <Sparkles className="w-3.5 h-3.5" />
                Analyze Resume
              </Link>
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  );
}
