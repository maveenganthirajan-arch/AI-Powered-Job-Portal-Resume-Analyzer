"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { GlassCard } from "@/components/glass-card";
import { JobCard } from "@/components/job-card";
import { JobData } from "@/types";
import { Bookmark, Briefcase, ArrowRight } from "lucide-react";

export default function SavedJobsPage() {
  const [savedJobs, setSavedJobs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSavedJobs();
  }, []);

  const fetchSavedJobs = async () => {
    try {
      const res = await fetch("/api/saved-jobs");
      if (res.ok) {
        const data = await res.json();
        setSavedJobs(data.savedJobs || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="space-y-1">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Saved Jobs
        </h1>
        <p className="text-xs sm:text-sm text-slate-400">
          Bookmarked opportunities you want to research or apply for later.
        </p>
      </div>

      {loading ? (
        <div className="py-20 text-center text-slate-400">Loading saved jobs...</div>
      ) : savedJobs.length === 0 ? (
        <GlassCard className="p-12 text-center space-y-4">
          <Bookmark className="w-10 h-10 text-slate-500 mx-auto" />
          <h3 className="text-base font-bold text-white">No saved jobs yet</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Click the bookmark icon on any job card in the search catalog to save positions for easy access.
          </p>
          <Link
            href="/jobs"
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-violet-600 text-white text-xs font-semibold"
          >
            Explore Jobs <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </GlassCard>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {savedJobs.map((item) => (
            <JobCard key={item.id} job={item.job} isSavedInitial={true} />
          ))}
        </div>
      )}
    </div>
  );
}
