"use client";

import React, { useState, useEffect } from "react";
import { GlassCard } from "@/components/glass-card";
import { getStatusColor, formatDate } from "@/lib/utils";
import { ScoreCard } from "@/components/score-card";
import {
  Users,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  FileText,
  Sparkles,
  Calendar,
  X,
  ExternalLink,
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function RecruiterApplicantsPage() {
  const [applicants, setApplicants] = useState<any[]>([
    {
      id: "app-alex",
      candidate: { name: "Alex Carter", email: "alex.carter@example.com", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=250&q=80" },
      job: { title: "Senior Frontend Developer", department: "Google Cloud Console" },
      status: "SHORTLISTED",
      matchScore: 85,
      appliedAt: "2026-04-15T09:15:00Z",
      resume: { fileName: "Alex_Carter_Senior_Frontend.pdf", extractedText: "5+ years React, Next.js, TypeScript, Micro-frontends, Lighthouse 98, Jest, Vitest." },
    },
    {
      id: "app-priya",
      candidate: { name: "Priya Sharma", email: "priya.sharma@example.com", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=250&q=80" },
      job: { title: "Full Stack Developer", department: "Reality Labs" },
      status: "INTERVIEW",
      matchScore: 91,
      appliedAt: "2026-04-14T11:45:00Z",
      resume: { fileName: "Priya_Sharma_FullStack.pdf", extractedText: "Full Stack React, Node.js, GraphQL, PostgreSQL, Redis, WebSockets, Docker." },
    },
    {
      id: "app-rahul",
      candidate: { name: "Rahul Mehta", email: "rahul.mehta@example.com", avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=250&q=80" },
      job: { title: "Backend Developer", department: "AWS Infrastructure" },
      status: "APPLIED",
      matchScore: 72,
      appliedAt: "2026-04-12T16:20:00Z",
      resume: { fileName: "Rahul_Mehta_Backend.pdf", extractedText: "Go, Node.js, AWS, Kubernetes, Distributed Systems, Kafka." },
    },
    {
      id: "app-emily",
      candidate: { name: "Emily Davis", email: "emily.davis@example.com", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=250&q=80" },
      job: { title: "UI/UX Designer", department: "Design Systems" },
      status: "IN_REVIEW",
      matchScore: 88,
      appliedAt: "2026-04-10T13:00:00Z",
      resume: { fileName: "Emily_Davis_ProductDesign.pdf", extractedText: "Figma design systems tokens, prototyping, user testing, accessibility." },
    },
    {
      id: "app-james",
      candidate: { name: "James Wilson", email: "james.wilson@example.com", avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=250&q=80" },
      job: { title: "Data Analyst", department: "Content Analytics" },
      status: "REJECTED",
      matchScore: 48,
      appliedAt: "2026-04-08T15:30:00Z",
      resume: { fileName: "James_Wilson_Data.pdf", extractedText: "SQL, Python, Excel, basic Tableau." },
    },
    {
      id: "app-john",
      candidate: { name: "John Doe", email: "john@example.com", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80" },
      job: { title: "Senior Frontend Developer", department: "Google Cloud Console" },
      status: "INTERVIEW",
      matchScore: 78,
      appliedAt: "2026-04-15T10:30:00Z",
      resume: { fileName: "John_Doe_Senior_Frontend_Resume_2026.pdf", extractedText: "Senior Frontend Engineer, 5+ years React, Next.js, TypeScript, Tailwind, REST/GraphQL." },
    },
  ]);

  const [filterStatus, setFilterStatus] = useState("ALL");
  const [selectedCandidate, setSelectedCandidate] = useState<any | null>(null);

  const statuses = ["ALL", "APPLIED", "IN_REVIEW", "SHORTLISTED", "INTERVIEW", "OFFERED", "REJECTED"];

  const handleStatusChange = (appId: string, newStatus: string) => {
    setApplicants((prev) =>
      prev.map((a) => (a.id === appId ? { ...a, status: newStatus } : a))
    );
    if (selectedCandidate && selectedCandidate.id === appId) {
      setSelectedCandidate({ ...selectedCandidate, status: newStatus });
    }
  };

  const filtered =
    filterStatus === "ALL"
      ? applicants
      : applicants.filter((a) => a.status === filterStatus);

  return (
    <div className="space-y-8">
      <div className="space-y-1">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Applicant Pipeline
        </h1>
        <p className="text-xs sm:text-sm text-slate-400">
          Review candidates, inspect AI match scores, and advance stages through the hiring funnel.
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 rounded-2xl bg-white/5 border border-white/10 w-fit">
        {statuses.map((st) => (
          <button
            key={st}
            onClick={() => setFilterStatus(st)}
            className={cn(
              "px-3 py-1.5 rounded-xl text-xs font-semibold transition-all",
              filterStatus === st
                ? "bg-violet-600 text-white shadow-md shadow-violet-500/25"
                : "text-slate-400 hover:text-white hover:bg-white/5"
            )}
          >
            {st === "ALL" ? `All (${applicants.length})` : st.replace("_", " ")}
          </button>
        ))}
      </div>

      {/* Applicants Table */}
      <GlassCard className="p-0 overflow-hidden border-white/15">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-white/10 bg-white/[0.02] text-slate-400">
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px]">
                  Candidate
                </th>
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px]">
                  Applied Job
                </th>
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px]">
                  Match Score
                </th>
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px]">
                  Pipeline Stage
                </th>
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px]">
                  Applied Date
                </th>
                <th className="py-4 px-6 font-semibold uppercase tracking-wider text-[11px] text-right">
                  Action
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filtered.map((app) => {
                const colors = getStatusColor(app.status);
                return (
                  <tr key={app.id} className="hover:bg-white/[0.03] transition-colors">
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                        <img
                          src={app.candidate.avatar}
                          alt={app.candidate.name}
                          className="w-9 h-9 rounded-full object-cover border border-white/20"
                        />
                        <div>
                          <span className="font-semibold text-white block">
                            {app.candidate.name}
                          </span>
                          <span className="text-[11px] text-slate-400">{app.candidate.email}</span>
                        </div>
                      </div>
                    </td>

                    <td className="py-4 px-6">
                      <span className="font-medium text-white block">{app.job.title}</span>
                      <span className="text-[11px] text-slate-400">{app.job.department}</span>
                    </td>

                    <td className="py-4 px-6">
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-aqua/10 border border-aqua/30 text-aqua font-bold text-xs">
                        <Sparkles className="w-3 h-3" />
                        {app.matchScore}% Match
                      </span>
                    </td>

                    <td className="py-4 px-6">
                      {/* Interactive Status Changer Dropdown */}
                      <select
                        value={app.status}
                        onChange={(e) => handleStatusChange(app.id, e.target.value)}
                        className={cn(
                          "px-2.5 py-1 rounded-xl text-xs font-semibold border bg-midnight-900 cursor-pointer focus:outline-none",
                          colors.text,
                          colors.border
                        )}
                      >
                        <option value="APPLIED">Applied</option>
                        <option value="IN_REVIEW">In Review</option>
                        <option value="SHORTLISTED">Shortlisted</option>
                        <option value="INTERVIEW">Interview</option>
                        <option value="OFFERED">Offered</option>
                        <option value="REJECTED">Rejected</option>
                      </select>
                    </td>

                    <td className="py-4 px-6 text-slate-400 font-mono text-[11px]">
                      {formatDate(app.appliedAt)}
                    </td>

                    <td className="py-4 px-6 text-right">
                      <button
                        onClick={() => setSelectedCandidate(app)}
                        className="px-3 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-white text-[11px] font-semibold transition-colors"
                      >
                        Inspect AI Match
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </GlassCard>

      {/* Candidate Details Drawer Modal */}
      {selectedCandidate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-midnight-950/80 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-xl glass-panel border border-white/20 p-6 md:p-8 rounded-3xl shadow-2xl overflow-y-auto max-h-[90vh] space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <img
                  src={selectedCandidate.candidate.avatar}
                  alt={selectedCandidate.candidate.name}
                  className="w-12 h-12 rounded-2xl object-cover border border-violet-500/40"
                />
                <div>
                  <h3 className="text-lg font-bold text-white">{selectedCandidate.candidate.name}</h3>
                  <p className="text-xs text-slate-400">{selectedCandidate.candidate.email}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedCandidate(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Score gauge and breakdown */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 p-4 rounded-2xl bg-white/5 border border-white/10">
              <ScoreCard
                score={selectedCandidate.matchScore}
                label="Evaluated Match"
                size="md"
              />
              <div className="space-y-1 text-xs text-slate-300">
                <div className="font-semibold text-white">40/25/20/15 Rubric Breakdown:</div>
                <div>• Skills Match (40%): {Math.min(95, selectedCandidate.matchScore + 8)}%</div>
                <div>• Experience Tenure (25%): {Math.min(90, selectedCandidate.matchScore + 2)}%</div>
                <div>• Project Relevance (20%): {selectedCandidate.matchScore}%</div>
                <div>• Education/Certs (15%): {Math.max(65, selectedCandidate.matchScore - 5)}%</div>
              </div>
            </div>

            {/* Resume Summary */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Resume Overview ({selectedCandidate.resume.fileName})
              </h4>
              <div className="p-4 rounded-xl bg-midnight-900/90 border border-white/10 text-xs text-slate-300 font-mono leading-relaxed max-h-40 overflow-y-auto">
                {selectedCandidate.resume.extractedText}
              </div>
            </div>

            {/* Stage advancement controls */}
            <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">Stage:</span>
                <select
                  value={selectedCandidate.status}
                  onChange={(e) => handleStatusChange(selectedCandidate.id, e.target.value)}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold border border-violet-500/40 bg-midnight-900 text-white"
                >
                  <option value="APPLIED">Applied</option>
                  <option value="IN_REVIEW">In Review</option>
                  <option value="SHORTLISTED">Shortlisted</option>
                  <option value="INTERVIEW">Interview</option>
                  <option value="OFFERED">Offered</option>
                  <option value="REJECTED">Rejected</option>
                </select>
              </div>

              <button
                onClick={() => setSelectedCandidate(null)}
                className="px-5 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold"
              >
                Close Inspection
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
