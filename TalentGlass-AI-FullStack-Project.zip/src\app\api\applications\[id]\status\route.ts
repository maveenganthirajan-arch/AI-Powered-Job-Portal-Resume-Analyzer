import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { applicationStatusUpdateSchema } from "@/lib/validations";

export async function PATCH(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== "RECRUITER") {
      return NextResponse.json({ error: "Recruiter authorization required" }, { status: 403 });
    }

    const body = await req.json();
    const validated = applicationStatusUpdateSchema.parse(body);

    const application = await db.application.findUnique({
      where: { id: params.id },
      include: {
        job: { include: { company: true } },
        candidate: true,
      },
    });

    if (!application) {
      return NextResponse.json({ error: "Application not found" }, { status: 404 });
    }

    // Verify company ownership
    if (application.job.company.ownerId !== user.id) {
      return NextResponse.json({ error: "Not authorized to manage this application" }, { status: 403 });
    }

    const updated = await db.application.update({
      where: { id: params.id },
      data: {
        status: validated.status,
        updatedAt: new Date(),
      },
    });

    // Create interview record if scheduled
    if (validated.status === "INTERVIEW") {
      const interviewDate = new Date();
      interviewDate.setDate(interviewDate.getDate() + 3);
      interviewDate.setHours(14, 0, 0, 0);

      await db.interview.create({
        data: {
          applicationId: application.id,
          scheduledAt: interviewDate,
          meetingLink: "https://meet.google.com/tg-int-2026",
          notes: "Round 1: System architecture & Technical portfolio deep dive",
        },
      });
    }

    // Notify candidate of status update
    await db.notification.create({
      data: {
        userId: application.candidateId,
        title: `Application Status: ${validated.status.replace("_", " ")}`,
        message: `Your application status for ${application.job.title} was updated to ${validated.status.replace("_", " ")}.`,
        type: validated.status === "INTERVIEW" ? "INTERVIEW_INVITE" : "APPLICATION_STATUS",
        link: "/candidate/applications",
      },
    });

    return NextResponse.json({ success: true, application: updated });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}
