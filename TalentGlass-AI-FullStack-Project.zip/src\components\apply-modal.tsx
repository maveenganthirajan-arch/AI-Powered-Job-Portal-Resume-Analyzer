"use client";

import React, { useState, useEffect } from "react";
import { JobData, ResumeData } from "@/types";
import {
  X,
  Sparkles,
  FileText,
  CheckCircle2,
  AlertCircle,
  Loader2,
  ArrowRight,
  Briefcase,
} from "lucide-react";
import { GlassCard } from "./glass-card";

interface ApplyModalProps {
  job: JobData | null;
  isOpen: boolean;
  onClose: () => void;
  onApplicationSubmitted?: () => void;
}

export function ApplyModal({
  job,
  isOpen,
  onClose,
  onApplicationSubmitted,
}: ApplyModalProps) {
  const [resumes, setResumes] = useState<ResumeData[]>([]);
  const [selectedResumeId, setSelectedResumeId] = useState<string>("");
  const [coverLetter, setCoverLetter] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);

  useEffect(() => {
    if (isOpen) {
      fetchResumes();
      setIsSuccess(false);
      setError(null);
    }
  }, [isOpen]);

  const fetchResumes = async () => {
    try {
      const res = await fetch("/api/resumes");
      if (res.ok) {
        const data = await res.json();
        setResumes(data.resumes || []);
        if (data.resumes?.length > 0) {
          setSelectedResumeId(data.resumes[0].id);
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  if (!isOpen || !job) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedResumeId) {
      setError("Please select or upload a resume to proceed.");
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const res = await fetch("/api/applications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          jobId: job.id,
          resumeId: selectedResumeId,
          coverLetter,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to submit application");
      }

      setIsSuccess(true);
      if (onApplicationSubmitted) {
        onApplicationSubmitted();
      }
    } catch (err: any) {
      setError(err.message || "Something went wrong.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-midnight-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl glass-panel border border-white/20 p-6 md:p-8 rounded-3xl shadow-2xl overflow-hidden">
        {/* Glow effect */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-gradient-to-bl from-violet-600/20 to-transparent pointer-events-none rounded-bl-full" />

        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-violet-600/20 border border-violet-500/30 flex items-center justify-center text-aqua">
              <Briefcase className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Apply for Position</h3>
              <p className="text-xs text-slate-400">
                {job.title} · {job.company?.name || "TechCorp"}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="py-8 text-center space-y-4">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h4 className="text-xl font-bold text-white">Application Submitted!</h4>
            <p className="text-sm text-slate-300 max-w-md mx-auto">
              Your resume and profile have been delivered to the hiring team at{" "}
              <span className="text-white font-medium">{job.company?.name || "the company"}</span>.
              You can track your real-time status in the Application Tracker.
            </p>
            <div className="pt-4 flex justify-center gap-3">
              <button
                onClick={onClose}
                className="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold"
              >
                Close
              </button>
              <a
                href="/candidate/applications"
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-aqua text-white text-xs font-semibold shadow-lg shadow-violet-500/20"
              >
                View Applications
              </a>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-6 space-y-5">
            {error && (
              <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Select Resume */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">
                Select Your Resume
              </label>
              {resumes.length === 0 ? (
                <div className="p-4 rounded-2xl border border-dashed border-white/20 bg-white/5 text-center">
                  <p className="text-xs text-slate-400">No resumes found in your profile.</p>
                  <a
                    href="/candidate/resume"
                    className="inline-block mt-2 text-xs font-semibold text-aqua hover:underline"
                  >
                    + Upload Resume in Analyzer
                  </a>
                </div>
              ) : (
                <div className="space-y-2">
                  {resumes.map((r) => (
                    <label
                      key={r.id}
                      className={`flex items-center justify-between p-3.5 rounded-xl border cursor-pointer transition-all ${
                        selectedResumeId === r.id
                          ? "bg-violet-600/15 border-violet-500 text-white"
                          : "bg-white/5 border-white/10 text-slate-300 hover:bg-white/10"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <FileText className="w-4 h-4 text-aqua" />
                        <div>
                          <p className="text-xs font-medium text-white">{r.fileName}</p>
                          <p className="text-[10px] text-slate-400">
                            Uploaded {new Date(r.uploadedAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <input
                        type="radio"
                        name="resumeChoice"
                        value={r.id}
                        checked={selectedResumeId === r.id}
                        onChange={() => setSelectedResumeId(r.id)}
                        className="accent-aqua h-4 w-4"
                      />
                    </label>
                  ))}
                </div>
              )}
            </div>

            {/* AI Match Snapshot Notice */}
            <div className="flex items-center gap-2 p-3 rounded-xl bg-aqua/10 border border-aqua/30 text-xs text-aqua">
              <Sparkles className="w-4 h-4 shrink-0" />
              <span>
                TalentGlass AI will generate an instant match score for the recruiter based on your technical skills and experience.
              </span>
            </div>

            {/* Cover Note */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">
                Cover Note / Message to Recruiter (Optional)
              </label>
              <textarea
                rows={3}
                value={coverLetter}
                onChange={(e) => setCoverLetter(e.target.value)}
                placeholder="Briefly state why you're a great fit for this role..."
                className="w-full rounded-xl bg-white/5 border border-white/10 p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-violet-500 transition-colors"
              />
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting || !selectedResumeId}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-aqua text-white text-xs font-bold shadow-lg shadow-violet-500/20 hover:opacity-95 disabled:opacity-50 flex items-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    Submitting Application...
                  </>
                ) : (
                  <>
                    Confirm & Apply
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
