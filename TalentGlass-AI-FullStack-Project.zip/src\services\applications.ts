import { db } from "@/lib/db";
import { ApplicationData, ApplicationStatus } from "@/types";

export async function getCandidateApplications(candidateId: string): Promise<ApplicationData[]> {
  const applications = await db.application.findMany({
    where: { candidateId },
    include: {
      job: {
        include: { company: true },
      },
      resume: true,
    },
    orderBy: { appliedAt: "desc" },
  });

  return applications.map((app) => ({
    ...app,
    status: app.status as ApplicationStatus,
    job: {
      ...app.job,
      requirements: JSON.parse(app.job.requirements || "[]"),
      benefits: JSON.parse(app.job.benefits || "[]"),
      requiredSkills: JSON.parse(app.job.requiredSkills || "[]"),
      status: app.job.status as any,
    },
    resume: {
      ...app.resume,
      parsedSkills: JSON.parse(app.resume.parsedSkills || "[]"),
    },
  }));
}

export async function getRecruiterApplicants(recruiterUserId: string, jobId?: string) {
  const company = await db.company.findUnique({
    where: { ownerId: recruiterUserId },
  });

  if (!company) {
    return [];
  }

  const where: any = {
    job: { companyId: company.id },
  };

  if (jobId) {
    where.jobId = jobId;
  }

  const applications = await db.application.findMany({
    where,
    include: {
      candidate: {
        select: {
          id: true,
          name: true,
          email: true,
          avatar: true,
        },
      },
      job: {
        select: {
          id: true,
          title: true,
          department: true,
        },
      },
      resume: true,
      interviews: true,
    },
    orderBy: { appliedAt: "desc" },
  });

  return applications;
}

export async function updateApplicationStatus(
  applicationId: string,
  status: ApplicationStatus,
  notes?: string
) {
  return db.application.update({
    where: { id: applicationId },
    data: {
      status,
      updatedAt: new Date(),
    },
  });
}
