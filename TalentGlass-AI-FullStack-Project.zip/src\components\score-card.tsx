"use client";

import React from "react";
import { cn } from "@/lib/utils";
import { Sparkles, CheckCircle2, AlertCircle, ArrowUpRight } from "lucide-react";
import Link from "next/link";

interface ScoreCardProps {
  score?: number;
  label?: string;
  size?: "sm" | "md" | "lg";
  breakdown?: {
    skillsMatch?: number;
    experience?: number;
    projects?: number;
    education?: number;
  };
  showBreakdown?: boolean;
  className?: string;
}

export function ScoreCard({
  score = 78,
  label = "Good Match",
  size = "md",
  breakdown = {
    skillsMatch: 88,
    experience: 80,
    projects: 75,
    education: 70,
  },
  showBreakdown = false,
  className,
}: ScoreCardProps) {
  // SVG circular gauge math
  const radius = size === "lg" ? 64 : size === "sm" ? 36 : 48;
  const stroke = size === "lg" ? 9 : size === "sm" ? 6 : 7;
  const normalizedRadius = radius - stroke * 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  const getScoreColor = () => {
    if (score >= 80) return "text-aqua";
    if (score >= 65) return "text-[#35D6C5]";
    if (score >= 50) return "text-amber-400";
    return "text-rose-400";
  };

  return (
    <div className={cn("flex flex-col items-center justify-center", className)}>
      <div className="relative flex items-center justify-center">
        <svg
          height={radius * 2}
          width={radius * 2}
          className="transform -rotate-90"
        >
          {/* Background circle track */}
          <circle
            stroke="rgba(255, 255, 255, 0.08)"
            fill="transparent"
            strokeWidth={stroke}
            r={normalizedRadius}
            cx={radius}
            cy={radius}
          />
          {/* Animated gradient progress circle */}
          <circle
            stroke="url(#scoreGradient)"
            fill="transparent"
            strokeWidth={stroke}
            strokeDasharray={`${circumference} ${circumference}`}
            style={{ strokeDashoffset }}
            strokeLinecap="round"
            className="transition-all duration-1000 ease-out"
            r={normalizedRadius}
            cx={radius}
            cy={radius}
          />
          <defs>
            <linearGradient id="scoreGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#7C5CFC" />
              <stop offset="100%" stopColor="#35D6C5" />
            </linearGradient>
          </defs>
        </svg>

        {/* Center score readout */}
        <div className="absolute flex flex-col items-center justify-center text-center">
          <span
            className={cn(
              "font-bold tracking-tight text-white",
              size === "lg" ? "text-4xl" : size === "sm" ? "text-xl" : "text-2xl"
            )}
          >
            {score}%
          </span>
          {size !== "sm" && (
            <span className="text-[10px] font-medium uppercase tracking-wider text-slate-400">
              Match
            </span>
          )}
        </div>
      </div>

      <div className="mt-3 text-center">
        <span
          className={cn(
            "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium border",
            score >= 70
              ? "bg-aqua/10 text-aqua border-aqua/30"
              : "bg-amber-500/10 text-amber-400 border-amber-500/30"
          )}
        >
          <Sparkles className="w-3 h-3" />
          {label}
        </span>
      </div>

      {showBreakdown && breakdown && (
        <div className="w-full mt-6 space-y-3 pt-4 border-t border-white/10 text-left">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Required skills (40%)</span>
            <span className="font-semibold text-slate-200">{breakdown.skillsMatch || 88}%</span>
          </div>
          <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-violet-500 to-aqua rounded-full"
              style={{ width: `${breakdown.skillsMatch || 88}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Relevant experience (25%)</span>
            <span className="font-semibold text-slate-200">{breakdown.experience || 80}%</span>
          </div>
          <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-violet-500 to-aqua rounded-full"
              style={{ width: `${breakdown.experience || 80}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Project relevance (20%)</span>
            <span className="font-semibold text-slate-200">{breakdown.projects || 75}%</span>
          </div>
          <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-violet-500 to-aqua rounded-full"
              style={{ width: `${breakdown.projects || 75}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Education & certs (15%)</span>
            <span className="font-semibold text-slate-200">{breakdown.education || 70}%</span>
          </div>
          <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-violet-500 to-aqua rounded-full"
              style={{ width: `${breakdown.education || 70}%` }}
            />
          </div>
        </div>
      )}
    </div>
  );
}
